<?php 

if ( ! function_exists('get_own_ip')) {
	
	/**
	 * Get the public IP address of the server running this script.
	 *
	 * @return string IP address
	 */
	function get_own_ip() {
		$sock = socket_create(AF_INET, SOCK_DGRAM, SOL_UDP);
		socket_connect($sock, '8.8.8.8', 80); // IP of Google public DNS server

		socket_getsockname($sock, $addr);
		socket_shutdown($sock);
		socket_close($sock);

		return $addr;
	}
}

if ( ! function_exists('closest_server')) {

	/**
	* @param array $servers - IP addresses of servers in cluster
	* 
	* @return string closest IP address from given list. NB: Could be self!
	*/
	function closest_server(array $servers) {
		// TODO: Opportunity to return sooner by doing these in parallel
		
		$min_ping = 1e6;
		$self = false;
		foreach($servers as $server) {
			$pingresult = exec("/bin/ping -W 1 -c 1 " . $server);
			preg_match('/rtt min\/avg\/max\/mdev = ([\d\.]+)\//', $pingresult, $match);
			
			if (count($match) != 2) { continue; }
			
			$time = floatval($match[1]);
			if ($time < $min_ping) {
				$min_ping = $time;
				$self = $server;
			}
		}
		
		return $self;
	}
}
