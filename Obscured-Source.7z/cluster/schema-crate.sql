-- Base schema used to record uploads to the server

-- Create the database/schema on the server. The name is prefixed with a
-- random string in order to discourage certain kinds of SQL injection
-- attacks.

--
-- Table structure for table "uploads_efKz69bw8"
--
CREATE TABLE IF NOT EXISTS A71uVTY_obscured_files.uploads_efKz69bw8 (

  -- The 8 char random string crated for each file is used as the primary 
  -- key and ID for each entry
  "id" string primary key,
  
  -- Random name and original name are as anticipated, with the exception
  -- that random name now no longer includes the uploads directory as was
  -- the case with the file based system
  "random_name" string,
  "original_name" string,
  
  -- The SHA1 is assumed to always be stored as a 40 character hex encoded
  -- string.
  -- Note that in future, if storage becomes limited, this can potentially
  -- be reduced to a binary(20) column by storing it in raw form.
  "sha1" string,
  
  -- The password is stored as a varchar(63) since most password hashing
  -- schemes will create a hash less than 60 characters long. The 60 
  -- character limit in particular, comes from the documentation on the
  -- "password_hash" function in the PHP documentation.
  "password" string,
  
  -- The server(s) on which the file is available.
  "location" array (ip),
  
  -- The upload time is stored as Unix timestamp
  "uploaded_at" integer,
  
  -- The accessed_at column represents the last time that the file was accessed
  -- by a user.
  "accessed_at" integer,
  
  -- The delete_at column represents the suggested delete time for the file
  -- The column is nullable so that if it is NULL, then by implication, no
  -- delete time was suggested by the user.
  "delete_at" integer
  
) with (number_of_replicas = 1, column_policy = 'strict');