<?php 

/*
 * This script is used to make modifications to the PeerVPN configuration file to
 * accommodate changes in the cluster membership and configuration defined in the
 * cluster.json file.
 *
 * While it makes the code somewhat more difficult to read, it has been coded so
 * that as far as possible it can be run on any configuration file (even a 
 * pre-configured one), and generate a new and valid result.
 *
 */
require_once 'util.php';

define('NETWORK_NAME', 'ObscuredFilesCrateNet');
define('PSK', 'jMxMTAyMjJiNTA5Mjg4MDRhNGNlOTBjMmJiZDEhMzBmYjIwZjQzZWY0YmM3ODY1ZjQxNmFjZDIxN');
define('PORT', 7777);


// Get list of servers and find own IP address
// -------------------------------------------------------------------------- //
$cluster = json_decode(file_get_contents(dirname(__DIR__).'/cluster.json'));
$servers = get_object_vars($cluster->servers);
$no_servers = count($servers);

$my_ip = get_own_ip();
$my_ip || ($my_ip = closest_server(array_keys($servers)));


// Change relevant values in default Crate configuration file
$config_path = '/etc/peervpn/peervpn.conf';
$config_string = file_get_contents($config_path);

// Set network name to non-default value
$config_string = preg_replace(
	'/^#?\s?networkname\s+.+$/m',
	"\nnetworkname ".NETWORK_NAME,
	$config_string);

// Set the PSK to allow decryption of network data
$config_string = preg_replace(
	'/^#?\s?psk\s+.+$/m',
	"\npsk ".PSK,
	$config_string);

// Set up peers
$peer_str = "\ninitpeers ";
foreach($servers as $ip => $server) {
	if ($ip == $my_ip) {
		continue;
	}
	$peer_str .= $ip.' '.PORT.' ';
}
$config_string = preg_replace(
	'/^#?\s?initpeers\s+.+$/m',
	$peer_str,
	$config_string);

// Bind to the right interface
$config_string = preg_replace(
	'/^#?\s?interface\s+.+$/m',
	"\ninterface peervpn0",
	$config_string);

// Set IP address
$config_string = preg_replace(
	'/^#?\s?ifconfig4\s+\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\/\d+/m',
	"\nifconfig4 ".$servers[$my_ip]->vpn_ip.'/24',
	$config_string);

// Set port number
$config_string = preg_replace(
	'/^#?\s?port\s+\d+/m',
	"\nport ".PORT,
	$config_string);

// Explicity disable IPv4
$config_string = preg_replace(
	'/^#?\s?enableipv6\s+yes/m',
	"\nenableipv6 no",
	$config_string);

// Enable relaying traffic
$config_string = preg_replace(
	'/^#?\s?enablerelay\s+no/m',
	"\nenablerelay yes",
	$config_string);

// Force dropping privileges
$config_string = preg_replace(
	'/^#?\s?enableprivdrop\s+(yes|no)/m',
	"\nenableprivdrop yes",
	$config_string);

// Set drop privilege user
$config_string = preg_replace(
	'/^#?\s?user\s+.+$/m',
	"\nuser nobody",
	$config_string);

// Set drop privilege group
$config_string = preg_replace(
	'/^#?\s?group\s+.+$/m',
	"\ngroup nogroup",
	$config_string);

// Set chroot directory
$config_string = preg_replace(
	'/^#?\s?chroot\s+.+$/m',
	"\nchroot /tmp/jail",
	$config_string);

// Write out again
file_put_contents($config_path, $config_string);