<?php 

/*
 * This script is used to make modifications to the Crate configuration file to
 * accommodate changes in the cluster membership and configuration defined in the
 * cluster.json file.
 *
 * While it makes the code somewhat more difficult to read, it has been coded so
 * that as far as possible it can be run on any configuration file (even a 
 * pre-configured one), and generate a new and valid result.
 *
 */
require_once 'util.php';


// Get list of servers and find own IP address
// -------------------------------------------------------------------------- //
$cluster = json_decode(file_get_contents(dirname(__DIR__).'/cluster.json'));
$servers = get_object_vars($cluster->servers);
$no_servers = count($servers);

$my_ip = get_own_ip();
$my_ip || ($my_ip = closest_server(array_keys($servers)));

// Change relevant values in default Crate configuration file
$config_path = '/usr/share/crate/config/crate.yml';
$config_string = file_get_contents($config_path);

// Set cluster name to non-default value
$config_string = preg_replace(
	'/#?\s?cluster\.name:\s+\S+/',
	'cluster.name: obscured_files',
	$config_string, 1);

// Set IP address to PeerVPN IP
$config_string = preg_replace(
	'/#?\s?network\.host:\s+\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/', 
	"\nnetwork.host: ".$servers[$my_ip]->vpn_ip,
	$config_string, 1);

// Enable multicast server discovery
$config_string = preg_replace(
	'/#?\s?discovery\.zen\.ping\.multicast\.enabled:\s+(true|false)/', 
	"\ndiscovery.zen.ping.multicast.enabled: true", 
	$config_string, 1);

// Set some cluster population based settings. Setting these with 2 or fewer
// servers causes functionality issues.
$config_string = preg_replace(
	'/#?\s?discovery\.zen\.minimum_master_nodes:\s+\d+/', 
	"\ndiscovery.zen.minimum_master_nodes: ".min(intval(floor($no_servers / 2) + 1), $no_servers - 1), 
	$config_string, 1);
$config_string = preg_replace(
	'/#?\s?gateway\.recover_after_nodes:\s+\d+/', 
	"\ngateway.recover_after_nodes: ".min(intval(floor($no_servers / 2) + 1), $no_servers - 1), 
	$config_string, 1);
$config_string = preg_replace(
	'/#?\s?gateway\.expected_nodes:\s+\d+/', 
	"\ngateway.expected_nodes: ".($no_servers > 2 ? $no_servers : 1), 
	$config_string, 1);

// Write out again
file_put_contents($config_path, $config_string);