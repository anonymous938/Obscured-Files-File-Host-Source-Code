#/bin/bash

# Get VPN IP by finding the first line in the output of "ifconfig" that has
# an address that begins with "10.6."
vpn_ip=`ifconfig | grep ':10\.6\.' | xargs | cut -f 2 -d' ' | cut -f 2 -d':'`

# HTTP test
curl "$vpn_ip:4200"

if [ $? -ne 0 ]
then
  echo "HTTP port test failed" >&2
  exit 1
fi

# TCP transport port test
nc -z "$vpn_ip" 4300
if [ $? -ne 0 ]
then
  echo "TCP port test failed" >&2
  exit 1
fi