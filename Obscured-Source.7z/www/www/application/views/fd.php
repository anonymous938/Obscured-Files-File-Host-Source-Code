<?php

define('UPLOADS_TABLE', 'uploads_efKz69bw8');
defined('BASEPATH') || define('BASEPATH', __DIR__);

require_once(__DIR__ . '/../config/uploads.php');

// TODO: It would be best to move this code into the controller
// Check for a password if necessary
if ( ! is_null($test_password))
{	
	$http_host = $_SERVER['HTTP_HOST'];
	$base_url = empty($_SERVER['HTTPS']) ?
		"http://" . $http_host . "/" : "https://" . $http_host . "/";
	
	// Check for empty password
	if (empty($password))
	{
		http_response_code(401);
		$params = http_build_query(
			['file' => $file, 'error' => 'Please enter a password']);
		header('Location: ' . $base_url . '?' . $params);
		die;
	}
	
	if ( ! password_verify($password, $test_password))
	{
		http_response_code(401);
		$params = http_build_query([
			'file' => $file, 
			'error' => 'Incorrect password entered. Please try again.']);
		header('Location: ' . $base_url . '?' . $params);
		die;
	}
}

$mime = mime_content_type($realpath);
header('Cache-Control: public, no-transform, must-revalidate');
header('Pragma: no-cache');
header('Content-Type:' . $mime);
header('Content-Disposition: attachment; filename=' . $original_name . '');
header('Content-Length: '. filesize($realpath));
header('Content-Transfer-Encoding: binary');
header('X-Accel-Redirect: ' . str_replace('/var/www', '', $realpath));
exit;
