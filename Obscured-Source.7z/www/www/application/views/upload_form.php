<?php include( "get.php"); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html lang="en">

<head>

    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Obscured files is a file sharing website for those who have privacy in mind.">
    <meta name="author" content="ObscuredFiles">

    <title>Obscured Files</title>
    <link href="<?php echo $base_url; ?>/public/css/tidy-un.css" rel="stylesheet">
    <?php include(__DIR__ . "/../../back/analyticstracking.php") ?>

</head>

<body data-target="#navbar-menu">
    <div class="container-io">
        <div class="data-wrap">
            <div class="data">1</div>
            <div class="data">1</div>
            <div class="data">0</div>
            <div class="data">0</div>
            <div class="data">1</div>
            <div class="data">1</div>
            <div class="data">0</div>
            <div class="data">0</div>
            <div class="data">0</div>
            <div class="data">1</div>
            <div class="data">0</div>
            <div class="data">1</div>
        </div>
    </div>
    <div class="navbar navbar-custom sticky" role="navigation">
        <div class="container">
            <div class=navbar-header>
                <a href="#navbar-toggle">
                    <button type=button class=navbar-toggle>
                        <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAQAAABKfvVzAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAAAmJLR0QAAKqNIzIAAAAJcEhZcwAADdcAAA3XAUIom3gAAAAHdElNRQfgCA4XNh5gRZQzAAAAQUlEQVQ4y2P8z0AaYCJR/WDUwLJAgEQNTO9J1MDQSZoGxsEXDyyLTtDYhkHp6Q4S/bCQRE+w/BMk0YbBF0q01wAAV8YLoT+H7iQAAAAldEVYdGRhdGU6Y3JlYXRlADIwMTYtMDgtMTRUMjM6NTQ6MzArMDI6MDBSIPQ9AAAAJXRFWHRkYXRlOm1vZGlmeQAyMDE2LTA4LTE0VDIzOjU0OjMwKzAyOjAwI31MgQAAABl0RVh0U29mdHdhcmUAd3d3Lmlua3NjYXBlLm9yZ5vuPBoAAAAASUVORK5CYII=">
                    </button>
                </a>
                <a class="navbar-brand logo" href="/">
                    <span class=fileico></span>
                    <span>Obscured Files</span>
                </a>
            </div>
            <div class="navbar-collapse collapse" id=navbar-menu>
                <ul class="nav navbar-nav navbar-right">
                    <li>
                        <a href="https://blog.obscuredfiles.com">Blog</a>
                    </li>
                    <li>
                        <a href="<?php echo $base_url; ?>/?donate" class="btn btn-inverse btn-bordered navbar-btn">Donate</a>
                    </li>
                </ul>
            </div>
            <?php if (!empty($error)): ?>
            <div class="fadeIn animated wow footerslogan navbar-brand logo" data-wow-delay=".1s">
                <?php echo $error ?>
            </div>
            <?php elseif ($base_url=="ONION_SERVICE" ): ?>
            <?php if (!empty(ONION_MESSAGE_URL)): ?>
            <a href="<?php echo ONION_MESSAGE_URL ?>" class="marquee marquee-speed-slow marquee-movement-smooth" data-marquee="<?php echo ONION_MESSAGE ?>"></a>
        </div>
        <?php else: ?>
        <div class="marquee marquee-speed-slow marquee-movement-smooth" data-marquee="<?php echo ONION_MESSAGE ?>"></div>
        <?php endif ?>
        <?php else: ?>
        <?php if (!empty(CLEAR_MESSAGE_URL)): ?>
        <a href="<?php echo CLEAR_MESSAGE_URL ?>" class="marquee marquee-speed-slow marquee-movement-smooth" data-marquee="<?php echo CLEAR_MESSAGE ?>"></a>
    </div>
    <?php else: ?>
    <div class="marquee marquee-speed-slow marquee-movement-smooth" data-marquee="<?php echo CLEAR_MESSAGE ?>"></div>
    <?php endif ?>
    <?php endif ?>
    </div>
    <!-- end container -->
    </div>
    <!-- End navbar-custom -->
    <div id="navbar-toggle" class="menudrop-display-block terms target">
        <a class="close" href="#navbar-menu"><h4>x</h4></a>
        <a href="<?php echo $base_url;?>/?partners" class="menu">Partnership/Helpers</a>
        <a href="<?php echo $base_url;?>/?donate" class="menu">Donate</a>
        </li>
        <a href="<?php echo $base_url;?>/?api" class="menu">API Developer Area</a>
        <a href="<?php echo $base_url;?>/?shame" class="menu">Shame Wall</a>
        <a href="https://blog.obscuredfiles.com/" class="menu">Blog (new)</a>
    </div>

    <!-- HOME -->
    <section class="home home-form-left" id="home">
        <!-- <div class="bg-overlay"></div> -->
        <div class="container">
            <div class="row">
                <div class="textarea col-md-6 col-sm-6">

                    <div class="home-wrapper">
                        <h2 class="animated fadeInDown wow">
              <span class="text-colored">Obscured Files</span> puts privacy first.
            </h2>
                        <ul class="animated fadeInDown wow intro-list" data-wow-delay=".2s">
                            <li><strong>File Retention time is:</strong> One hour for pictures and webm, as long as possible for files</li>
                            <li><strong>Allowed File Types:</strong> 7z (1-10) gif gz gzip jpg jpeg png rar tar torrent txt webm zip</li>
                            <li><strong>Max Upload Size:</strong> 500M</li>
                        </ul>
                        <ul class="animated fadeInDown wow intro-list" data-wow-delay=".4s">
                            <!-- <li>By uploading you are agreeing to the <a href="#terms">Terms and Conditions</a> and <a href="#privacy">Privacy Policy</a>.</li> -->
				<li>By uploading you are agreeing to the <a href="/?terms">Terms and Conditions</a> and <a href="/?privacy">Privacy Policy</a>.</li>
                        </ul>
                        <div class="clearfix"></div>
                    </div>
                    <!-- home wrapper -->

                </div>
                <!-- end col -->

                <div class="formarea col-md-6 col-sm-6">
                    <div class="home-wrapper">
                        <?php if (UPLOAD_OFFLINE) { include( "html/update.html"); } else { if (BALANCED) { include( "html/balance.php"); } else { include( "html/nobalance.php"); } include( "html/upload.html"); } ?>
                    </div>
                </div>

            </div>
            <!-- end row -->
        </div>
        <!-- end container -->
    </section>
    <!-- END HOME -->



    <!-- FEATURES -->
    <section class="section" id="features">
        <div class="container">

            <div class="row">
                <div class="col-sm-12 text-center">
                    <div class="title-box">

                        <h3 class="fadeIn animated wow" data-wow-delay=".1s">Why Obscured Files?</h3>
                        <div class="border"></div>
                    </div>
                </div>
            </div>
            <!-- end row -->

            <div class="row text-center">
                <div class="col-lg-3 col-sm-6 col-xs-12">
                    <div class="service-item animated fadeInLeft wow" data-wow-delay=".1s">
                        <h2><span class="distfile text-colored"></span></h2>
                        <div class="service-detail">
                            <h4>Distributed File Servers</h4>
                            <p>We spead out uploaded files towards multiple servers around the world to make sure that files are always available.</p>
                        </div>
                        <!-- /service-detail -->
                    </div>
                    <!-- /service-item -->
                </div>
                <!-- /col -->

                <div class="col-lg-3 col-sm-6 col-xs-12">
                    <div class="service-item animated fadeInDown wow" data-wow-delay=".3s">
                        <h2><span class="pricon text-colored"></span></h2>
                        <div class="service-detail">
                            <h4>Privacy Conscious Uploads</h4>
                            <p>We don't track users and provide not only <a href="http://obscuredtzevzthp.onion/">one</a> but <a href="http://obscured2s5avbsd.onion/">two</a> onion services for those who still think we do.</p>
                        </div>
                        <!-- /service-detail -->
                    </div>
                    <!-- /service-item -->
                </div>
                <!-- /col -->

                <div class="col-lg-3 col-sm-6 col-xs-12">
                    <div class="service-item animated fadeInRight wow" data-wow-delay=".5s">
                        <h2><span class="btcoin text-colored"></span></h2>
                        <div class="service-detail">
                            <h4>Ad Free, Supported By You</h4>
                            <p>We understand advertisements sucks. So we don't have any. Instead we are <a href=<?php echo $base_url;?>?donate>supported by you</a>.</p>
                        </div>
                        <!-- /service-detail -->
                    </div>
                    <!-- /service-item -->
                </div>
                <!-- /col -->

                <div class="col-lg-3 col-sm-6 col-xs-12">
                    <div class="service-item animated fadeInRight wow" data-wow-delay=".5s">
                        <h2><span class="clidne text-colored"></span></h2>
                        <div class="service-detail">
                            <h4>One Click and Done</h4>
                            <p>We provide download links that doesn't make you want to pull your hair out. One click and you have the file. No hoops. No bullshit. We even have a <a href=<?php echo $base_url;?>?api>simple upload API</a> to make it even easier.</p>
                        </div>
                        <!-- /service-detail -->
                    </div>
                    <!-- /service-item -->
                </div>
                <!-- /col -->
            </div>
            <!--end row -->


        </div>
        <!-- end container -->
    </section>
    <!-- END FEATURES -->

    <!-- FOOTER -->
	<?php include( "html/footer.php"); ?>
    <!-- END FOOTER -->
</body>

</html>