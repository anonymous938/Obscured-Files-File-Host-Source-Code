<section class="features" id=features>
	<div class=container>
		<div class="row">
			<div class="col-sm-12">
					<?php if (!empty($error)): ?>
						<span class="error"> <?php echo $error ?></span>
					<?php endif ?>
					<div class="row">
						<div class="col-sm-6"><h3>Download Link</h3>
							<code><a href="<?php echo $link; ?>" target="_BLANK"><?php echo $link; ?></a></code>
							<?php if (isset($link_hidden)): ?>
								<code><a href="<?php echo $link_hidden; ?>" target="_BLANK"><?php echo $link_hidden; ?></a></code>
							<?php endif ?>
						</div>
						<?php if (!empty($password)): ?>
							<div class="col-sm-6"><h3>Download Password</h3>
								<code><?php echo $password; ?></code>
							</div>
						<?php else: ?>
							<div class="col-sm-6"><h3>Download Password</h3>
								<code>No Download Password</code>
							</div>
						<?php endif ?>
						<div class="col-sm-12">
							<strong>Don't lose your download <?php if (!empty($password)): ?> or password<?php endif ?>... There is no way to recover it.</strong>
						</div>
					</div>

					<hr>

					<div class="row">
						<div class="col-sm-12">
							<p>Upload Information:</p>
						</div>
						<div class="col-sm-6">
							<code>SHA1: <?php echo $file_sha1; ?></code>
							<code>Delete: <a href="<?php echo $delete_link; ?>" target="_BLANK"><?php echo $delete_link; ?></a></code>
						</div>
						<div class="col-sm-6">
							<?php if ($obscured): ?>
								<code>Filename Successfully Obscured.</code>
							<?php endif ?>
							<?php if ($localhost || isset($torip) && $torip): ?>
								<code>File Uploaded Privately [Tor Detected]</code>
							<?php endif ?>
							<?php if (isset($delete_at)): ?>
								<code>File will be deleted in 24 hours.</code>
							<?php endif ?>
						</div>
					</div>						
			</div>
		</div>
	</div>
</section>