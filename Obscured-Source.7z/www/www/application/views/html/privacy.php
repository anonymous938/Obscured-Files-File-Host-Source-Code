<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html lang=en>

<head>
	<meta http-equiv=Content-Type content="text/html; charset=UTF-8">
	<meta name=viewport content="width=device-width, initial-scale=1.0">
	<title>Privacy Policy</title>
	<meta name="description" content="Our amazing Privacy Policy so users understand what we do to protect their anonymity and what ways we use any information collected.">
	<link href="<?php echo $base_url; ?>/public/css/tidy-un.css" rel="stylesheet">
	<?php include_once(__DIR__ . "/../../../back/analyticstracking.php") ?>
</head>

<body data-target="#navbar-menu">
			<?php include("header.php") ?>
	<section class="container headingpad home" id=home>
		<div class=row>
			<div class="col-sm-12">
				<h2>Privacy Policy</h2>
				<p>This Privacy Policy governs the manner in which Obscured Files collects, uses, maintains and discloses information collected from users (each, a "User") of the Clearnet: <a href="https://obscuredfiles.com/" target="_blank">https://obscuredfiles.com/</a> Hidden Service: <a href="http://obscuredtzevzthp.onion/" target="_blank">http://obscuredtzevzthp.onion/</a> websites ("Site"/"We").</p>
			</div>
		</div>
	</section>
	<section class="middlebox section" id=features>
		<div class="container">
			<div class="row">
				<div class="col-sm-12 apilinespace">
					<h3>Personal Identification Information</h3>
					<p>Users visit our Site anonymously. Obscured Files does not store logs upon the activity of our Site. The only time we can collect any personal information is when the user uploads a file. A user can upload a file with personal information embedded in such file. While we try our best to protect users information from being posted on our site, the user themselves are responsible for actions to keep their anonymously. </p>

					<h3>Third Party Information Collection</h3>
					<p>Obscured Files (Clearnet) uses Google Analytics to provide aggregated form statistics. We use these stats to improve the operation of the site and fix website issues before they are reported. The stats also provide information as to where the best location is to deploy a new server for the most effective downloading experience. If you don't want any information collected by Google Analytics you can get an AdBlocker (<a href="https://www.ublock.org/" target="_blank">uBlock</a>) or turn off <a href="http://www.computerhope.com/issues/ch000891.htm" target="_blank">javascript</a>. It's to be noted that Google Analytics's code is the <b>only</b> javascript on this website. It will work exactly the same without javscript enabled.</p>

					<h3>Web Browser Cookies</h3>
					<p>We have no cookies on this site. Instead we use randomly changing cryptographic post data to authenticate downloads.</p>

					<h3>How We Use Collected Information</h3>
					<p>Obscured Files may collect and use Users information for the following purposes:</p>
					<ul>
						<li>
							<i>To run and operate our Site</i>
							<br/> We store uploaded files on our server. When a User makes a request for a file, and the request is valid, we serve the requested file to the requesting User.
						</li>
					</ul>

					<h3>How We Protect Your Information</h3>
					<p>On our Clearnet site we provide a high security SSL certificate. The security of such certificate can be security audited <a href="https://www.ssllabs.com/ssltest/analyze.html?d=obscuredfiles.com" target="_BLANK">at any time</a>. At the same time, please check out our <a href="https://securityheaders.io/?q=https%3A%2F%2Fobscuredfiles.com%2F" target="_BLANK">header security</a>. We also have been <a href="http://dnsviz.net/d/obscuredfiles.com/analyze/" target="_BLANK">setup with verisign's DNS servers</a> that are outfitted with DNSSEC to protect against <a href="http://www.howtogeek.com/161808/htg-explains-what-is-dns-cache-poisoning/" target="_BLANK">DNS cache poisoning</a> while also providing origin authentication, data integrity, and authenticated denial of existence. These security features provides protection for all information transfer from the User to the Clearnet Site. The Hidden Service is within the encrypted network of tor. All connections are already encrypted and DNS leaking is no longer possible so these protections are not needed to securely transfer information.</p>
					<p>All files, with the exception of pictures and webms, are stored outside the web directory with obscured file names. Files are only accessable to the User when given the appropriate download link. When serving we pull the assigned (original if Obscured Filename not selected) name of the uploaded file from a database and serve the requested file named as such. Photos and Webms are only stored for one hour, after which they get deleted from our servers.</p>
					<p>To protect Users anonymously, we have rebuilt this site exceeding standard file security practices, do not store any logs, provide a hidden service site to enhance privacy for users that still think we do store logs (hidden services can not retreve IP addresses), we jailed our web server directory, initiated some of the highest possible PHP security practices, prevent as much as possible disk writes (All sessions are stored in RAM), and have even set a $100(US) reward for disclosing an exploit.

						<h3>Sharing Your Personal Information</h3>
						<p>Unless the user uploads or posts personal information, we do not have any. If the user did upload personal information, it would only be accessable from appropriate download link. If a User chooses to password protect their download link there is no way to access the file unless the appropate password is provided on the appropate download link. All randomly generated passwords are saved in hash format.</p>

						<h3>Changes To This Privacy Policy</h3>
						<p>Obscured Files has the discretion to update this privacy policy at any time. When we do, we will revise the updated date at the bottom of this page. We encourage Users to frequently check this page for any changes to stay informed about how we are helping to protect the personal information we collect. You acknowledge and agree that it is your responsibility to review this privacy policy periodically and become aware of modifications.</p>

						<h3>Your Acceptance Of These Terms</h3>
						<p>By using this Site, you signify your acceptance of this policy. If you do not agree to this policy, please do not use our Site. Your continued use of the Site following the posting of changes to this policy will be deemed your acceptance of those changes.</p>
					<h3>Contacting Us</h3>
					<p>If you have any questions about this Privacy Policy, the practices of this site, or your dealings with this site, please contact us on our our private email (<a href="mailto:admin@obscuredfiles.com">admin@obscuredfiles.com</a>).</p>

					<p>This document was last updated on April 12, 2016</p>
				</div>
			</div>
		</div>
	</section>
    <!-- FOOTER -->
	<?php include( "footer.php"); ?>
    <!-- END FOOTER -->
</body>

</html>