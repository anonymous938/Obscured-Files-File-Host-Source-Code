<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html lang=en>
	<head>
		<meta http-equiv=Content-Type content="text/html; charset=UTF-8">
		<meta name=viewport content="width=device-width, initial-scale=1.0">
		<title>Obscured Files - Shame Wall</title>
		<meta name=description content="A wall of shame for those who tested without our permission and then failed to break our security.">
		<meta name=author content=ObscuredFiles>
		<link href="<?php echo $base_url; ?>/public/css/tidy-un.css" rel="stylesheet">
    	<?php include_once(__DIR__ . "/../../../back/analyticstracking.php") ?>
    </head>
	<body data-target="#navbar-menu">
			<?php include("header.php") ?>
		<section class="home" id=home>
			<div class=container>
				<div class=row>
					<div class="col-sm-12">
					<h2>Shame Wall</h2>
					<p>Welcome to the Shame Wall! A page dedicated to individuals who tested without our permission and then failed to break our security. It will outline where exactly the attack came from, what tool(s) they used, and in which way we prevented it from affecting our operation.</p>
					</div>
				</div>
			</div>
		</section>
		<section class=section id=features>
			<div class=container>
				<div class="row">
					<div class="col-sm-12"><pre>IP: 76.125.208.177</pre>
					<p>On April 12, 2016, the main server was responding to a possible DOS attack. Lots of requests were coming from a single address that was doing tons of small uploads, going into different forbidden directories, being just a nuisance. It was going at a rate of about 100 requests a second for a good couple of minutes. No biggy we can handle that little extra load. But then it started uploading a shit ton of exploits (which failed by the way) at a consistent 100 request rate.</p>

					<p>This was filling up our failed upload log quickly being even more of a nuisance. Our DDOS filter kicked in and blocked the ip that you see above. Upon further inspection it seems that a person tried to test the site with Acunetix Web Vulnerability Scanner. We don't mind that people want to test the site, but let us know first so we can get ready. Then you could be eligible for the $100US prize if you break our security.</p>
					
					
					<h4>Shame on you. Shame on you.</h4></div>
				</div>
			</div>
		</section>
    <!-- FOOTER -->
	<?php include( "footer.php"); ?>
    <!-- END FOOTER -->
	</body>
</html>