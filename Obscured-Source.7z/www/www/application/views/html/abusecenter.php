﻿<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html lang=en>
	<head>
		<meta http-equiv=Content-Type content="text/html; charset=UTF-8">
		<meta name=viewport content="width=device-width, initial-scale=1.0">
		<title>Obscured Files - Abuse Center</title>
		<meta name=description content="The Abuse Center for all the information on how to and which ways you can report a not so nice file.">
		<meta name=author content=ObscuredFiles>
		<link href="<?php echo $base_url; ?>/public/css/tidy-un.css" rel="stylesheet">
    		<?php include_once(__DIR__ . "/../../../back/analyticstracking.php") ?>
	</head>
	<body data-target="#navbar-menu">
			<?php include("header.php") ?>
		<section class="container headingpad home" id=home>
				<div class=row>
					<div class="col-sm-12">
						<h2>Abuse Center</h2>
						<p>Per day (sometime per hour) we have several abuse requests demanding take downs for some not so nice things (Ex. Snuff films). We have an obligation to take down these files if they go against our terms and conditions or the law in the US (sometimes other countries). Other times we take them down because of an explanation to who it personally harms or if it could potentially harm someone (Blackmail files, hacking software, etc.) We knew that some abuse request will come if we made this site public.</p>
						<p>Because we have no tracking of users, and allow guests to upload, we also understand that this kind of privacy focused environment can attract some not so nice people. Those people will not follow the terms and
							conditions or laws. Some have argued (sometimes strongly) that we should "track and hand over these scum to the police." But we do not think that because of some bad apples we will need to track and remove the privacy from all our users.</p>

						<p>We have an astounding user base from journalists, privacy activist, and even a user that uses this site to share information about the internal workings of ISIS (We really hoped that one is a joke). People argue that privacy causes a lot of harm, and that we need to increase surveillance to prevent harm, however some cases there can be a lot more harm from not having privacy.</p>

						<p>This area is to provide information about making abuse requests and what ways we are making our abuse handling procedures more efficient.</p>
					</div>
				</div>
		</section>
		<section class="middlebox section" id=features>
			<div class="container">
				<div class="row">
					<div class="col-sm-12">
						<h2>What should I include in an abuse request?</h2>
						<p>Most people don't understand the sheer number of files that are being uploaded on a daily basis. To give you some insight we have an archive upload every 6 minutes and a picture upload every 2 seconds. We serve on average 6TB-9TB of content per day. This has been growing increasingly throughout the days. As such so have the abuse requests. So here is some of the outlines that need to be included within an abuse request. If you could do it in this order that would be awesome.</p>
							<ul>
								<li>The reason why it should be taken down (“The file in this archive is a hackergen.”)</li>
								<li>You need to include the file link. (https://obscuredfiles.com/?file=[8charlink])</li>
								<li>If it has password protect enabled you need to include the download password. (Download Password: 23i07powjbj4g)</li>
								<li>If it is an encrypted archive you need to include the password. (Password: hackernohacking)</li>
							</ul>
						<p>The extra that is not required for most requests (unless it falls out the scope of our terms and conditions)</p>
							<ul>
								<li>The person, group, or organization that it will harm or has the potential to harm. (The archive has some photos of intimate times with me and my gf. They are spreading it around to break us up)</li>
								<li>If it is a DMCA takedown notice you need to have it in the correct template with information about who we can contact and what copyright holders it infringes. (If it is yourself please do a traditional abuse request)</li>
							</ul>
					</div>
				</div>
			</div>
		</section>
		
		<section class="container headingpad home" id=home>
				<div class="row">
					<div class="col-sm-12">
						<p>To report a file you need to go through our email: <a href="mailto:admin@obscuredfiles.com">admin@obscuredfiles.com</a> <a href="/public/public_key.txt" target="\_BLANK\">PUBLIC KEY</a></p>
						<p>If you want to remain anonymous you can use a free disposable email address at <a href="https://www.guerrillamail.com/" target="\_BLANK\">https://www.guerrillamail.com/</a></p>
					</div>
				</div>
		</section>
    <!-- FOOTER -->
	<?php include( "footer.php"); ?>
    <!-- END FOOTER -->
	</body>
</html>