<div id="terms" class="terms target">
	<h2>Terms and Conditions</h2><a class="close" href="#"><h3>x</h3></a>
	<div class="center box">
		<p>These are the terms and conditions. Its main propose is to provide understanding and guidance to users of Obscured Files. Being such it will use layman terms and common English slang. </p>
		<p>Yo homey, welcome to Obscured Files. Obscured Files is a super-secret and super-private file sharing website, so that you can spread those files to all your hood. It窶冱 made to be so simple your half dog half muscle man would be able to use it. When your muscle dog visits the site and uploads those half decent biceps selfies he will know that it will be private and completely anonymous. No one (not even us) will be able to hook back those ripped biceps to his personal computer窶冱 location. How窶冱 that for awesome?
			<br> Being that we (Obscured Files) cannot identify and do not have any logs our legal liability for uploaded files are reduced. Oh I mean, yo being that is super-private even we are bullet proof protected from peeping eyes. But, ma gangsta homey, there are still bullets that can blow our shit up. Bullets fired from:</p>
		<ul>
			<li>Copyright lawyers.</li>
			<li>Parents and representing police of abused children.</li>
			<li><strike>Pimps</strike> Porn Actor's Managers.</li>
			<li>Hacking Software, Viruses, etc.</li>
			<li>Overall law enforcement.</li>
			<li>Jeff from down the street.</li>
		</ul>
		<p>So our word: 窶廛on窶冲 piss off the guys with power.窶�
			<br> If you窶决e going to anyway, even if we say <a href="http://usatoday30.usatoday.com/tech/news/story/2012-01-19/megaupload-feds-shutdown/52678528/1">don't</a>, at least <a href="/public/e91c0c1cb9bafcf072437e5b17a1366f.pdf">make it private</a> before uploading. </p>
		<p>If your one of the pissed off people above (Other than that piece of shit Jeff) you can <a href="/?abusecenter">find out which ways you can report</a>.</p>
		<p><strong>TL;DR Overestimating the size of your dick is a good way to disappoint people.</strong>
		</p>
		<p>
		</p>
		<h3>BORING BUT NECESSARY STUFF BELOW</h3>
		<h4> 1. Use of service </h4>
		<p>Users are solely responsible for the files that are uploaded. Obscuredfiles.com and those who work with the website can not be held responsible for the material.</p>
		<h4> 2. Files </h4>
		<p>While we try our best to keep all uploads active Obscuredfiles.com has no responsibility to maintain the uploaded files.</p>
		<h4> 3. Terms </h4>
		<p>Uploading is showing your acceptance of the terms and conditions and can therefore be held responsible for illegal and/or Copyright infringement material.</p>
		<h4> 4. Offenses </h4>
		<p>Do not upload anything that is illegal being that illegal files will be removed.</p>
		<h4> 5. Misuse </h4>
		<p>Files with the intention to cause harm to either the website, server, or users will be removed. </p>
		<p>This document was last updated on February 5, 2016</p>
		<a href="#navbar-menu">Go Back</a>
		<p></p>
	</div>
</div>
<div id="privacy" class="terms target">
	<h2>Privacy Policy</h2><a class="close" href="#"><h3>x</h3></a>
	<div class="center box">
		<p>This Privacy Policy governs the manner in which Obscured Files collects, uses, maintains and discloses information collected from users (each, a "User") of the Clearnet: <a href="https://obscuredfiles.com/" target="_blank">https://obscuredfiles.com/</a> Hidden Service: <a href="http://obscuredtzevzthp.onion/" target="_blank">http://obscuredtzevzthp.onion/</a> websites ("Site"/"We").</p>

		<h3>Personal Identification Information</h3>
		<p>Users visit our Site anonymously. Obscured Files does not store logs upon the activity of our Site. The only time we can collect any personal information is when the user uploads a file. A user can upload a file with personal information embedded in such file. While we try our best to protect users information from being posted on our site, the user themselves are responsible for actions to keep their anonymously. </p>

		<h3>Third Party Information Collection</h3>
		<p>Obscured Files (Clearnet) uses Google Analytics to provide aggregated form statistics. We use these stats to improve the operation of the site and fix website issues before they are reported. The stats also provide information as to where the best location is to deploy a new server for the most effective downloading experience. If you don't want any information collected by Google Analytics you can get an AdBlocker (<a href="https://www.ublock.org/" target="_blank">uBlock</a>) or turn off <a href="http://www.computerhope.com/issues/ch000891.htm" target="_blank">javascript</a>. It's to be noted that Google Analytics's code is the <b>only</b> javascript on this website. It will work exactly the same without javscript enabled.</p>

		<h3>Web Browser Cookies</h3>
		<p>We have no cookies on this site. Instead we use randomly changing cryptographic post data to authenticate downloads.</p>

		<h3>How We Use Collected Information</h3>
		<p>Obscured Files may collect and use Users information for the following purposes:</p>
		<ul>
			<li>
				<i>To run and operate our Site</i>
				<br> We store uploaded files on our server. When a User makes a request for a file, and the request is valid, we serve the requested file to the requesting User.
			</li>
		</ul>

		<h3>How We Protect Your Information</h3>
		<p>On our Clearnet site we provide a high security SSL certificate. The security of such certificate can be security audited <a href="https://www.ssllabs.com/ssltest/analyze.html?d=obscuredfiles.com" target="_BLANK">at any time</a>. At the same time, please check out our <a href="https://securityheaders.io/?q=https%3A%2F%2Fobscuredfiles.com%2F" target="_BLANK">header security</a>. We also have been <a href="http://dnsviz.net/d/obscuredfiles.com/analyze/" target="_BLANK">setup with verisign's DNS servers</a> that are outfitted with DNSSEC to protect against <a href="http://www.howtogeek.com/161808/htg-explains-what-is-dns-cache-poisoning/" target="_BLANK">DNS cache poisoning</a> while also providing origin authentication, data integrity, and authenticated denial of existence. These security features provides protection for all information transfer from the User to the Clearnet Site. The Hidden Service is within the encrypted network of tor. All connections are already encrypted and DNS leaking is no longer possible so these protections are not needed to securely transfer information.</p>
		<p>All files, with the exception of pictures and webms, are stored outside the web directory with obscured file names. Files are only accessable to the User when given the appropriate download link. When serving we pull the assigned (original if Obscured Filename not selected) name of the uploaded file from a database and serve the requested file named as such. Photos and Webms are only stored for one hour, after which they get deleted from our servers.</p>
		<p>To protect Users anonymously, we have rebuilt this site exceeding standard file security practices, do not store any logs, provide a hidden service site to enhance privacy for users that still think we do store logs (hidden services can not retreve IP addresses), we jailed our web server directory, initiated some of the highest possible PHP security practices, prevent as much as possible disk writes (All sessions are stored in RAM), and have even set a $100(US) reward for disclosing an exploit.

		</p>
		<h3>Sharing Your Personal Information</h3>
		<p>Unless the user uploads or posts personal information, we do not have any. If the user did upload personal information, it would only be accessable from appropriate download link. If a User chooses to password protect their download link there is no way to access the file unless the appropate password is provided on the appropate download link. All randomly generated passwords are saved in hash format.</p>

		<h3>Changes To This Privacy Policy</h3>
		<p>Obscured Files has the discretion to update this privacy policy at any time. When we do, we will revise the updated date at the bottom of this page. We encourage Users to frequently check this page for any changes to stay informed about how we are helping to protect the personal information we collect. You acknowledge and agree that it is your responsibility to review this privacy policy periodically and become aware of modifications.</p>

		<h3>Your Acceptance Of These Terms</h3>
		<p>By using this Site, you signify your acceptance of this policy. If you do not agree to this policy, please do not use our Site. Your continued use of the Site following the posting of changes to this policy will be deemed your acceptance of those changes.</p>

		<h3>Contacting Us</h3>
		<p>If you have any questions about this Privacy Policy, the practices of this site, or your dealings with this site, please contact us on our our private email (<a href="mailto:admin@obscuredfiles.com">admin@obscuredfiles.com</a>).</p>

		<p>This document was last updated on April 12, 2016</p>
		<a href="#navbar-menu">Go Back</a>
		<p></p>
	</div>
</div>