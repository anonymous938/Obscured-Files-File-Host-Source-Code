<!DOCTYPE html>

<html lang="en">
<head>
    <meta content="text/html; charset=utf-8" http-equiv="Content-Type">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <title>Obscured Files - API</title>
    <meta content="Developer area for obscuredfile's API." name="description">
    <meta content="ObscuredFiles" name="author">
    <link href="<?php echo $base_url; ?>/public/css/tidy-un.css" rel=
    "stylesheet">
    <?php include_once(__DIR__ . "/../../../back/analyticstracking.php") ?>
</head>

<body data-target="#navbar-menu">
    <?php include("header.php") ?>

    <section class="container headingpad home" id="home">
        <div class="row">
            <div class="col-sm-12">
                <h2>API</h2>


                <p>This page will outline the way to use obscuredfile's API.
                Like the website, we made it to be as simple as possible.</p>
            </div>
        </div>
    </section>


    <section class="middlebox section" id="features">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 apilinespace">
                    <h2>Access and Upload</h2>


                    <p>Like the rest of the site, the API is controlled by POST
                    data. You will need to curl post with a minimum of two
                    things; the file data and the API discriptor.</p>
                    <code>curl -F api= -F
                    userfile=@/root/catvideolist.txt
                    https://obscuredfiles.com/index.php/upload/do_upload</code>

                    <h3>To break it down:</h3>
                    <code>-F</code>

                    <p>Curl parameter to specify about multipart POST data.</p>
                    <code>api=</code>

                    <p>This is the API descriptor. It tells the server you want
                    a return of JSON not html. You need to add in the "=" to
                    have curl pass the multiform properly.</p>
                    <code>userfile=@/root/amazingcatvideolist.txt</code>

                    <p>Specifies the upload file.</p>
                    <code>https://obscuredfiles.com/index.php/upload/do_upload</code>

                    <p>The website's upload URL. Where to send the file for
                    processing. You can always specify specific servers using
                    their subdomains.</p>


                    <h3>What you get back when using the API.</h3>


                    <p>For this example we sent in the above cat video list
                    using curl and received:</p>
                    <code>{ "status": "success", "data": { "base_url":
                    "https://obscuredfiles.com", "password": false, "obscured":
                    false, "requestip": "127.0.0.1", "localhost": true,
                    "torip": false, "link":
                    "https://obscuredfiles.com/?file=voy5rh4f", "delete_link":
                    "https://obscuredfiles.com/?delete=voy5rh4f&k=6p9FwhXoNF4z",
                    "file_sha1": "f626e3685fad6f431b96cb96c0f7d3f238ae1aec",
                    "remake": false, "is_image": false, "file_type":
                    "text/plain", "delete_at": null } }</code>

                    <p>We get back the status code with all the information we
                    got out of the upload.</p>


                    <h3>Advanced variables</h3>


                    <p>You can pass these variables with the api to do some
                    customization on the upload.</p>
                    <code>obscure ("obscured" returns true|false)</code>

                    <p>This randomizes the file name upon upload.</p>
                    <code>protect ("password" password protects file and
                    outputs file)</code>

                    <p>Outputs a password with the download link. Password must
                    be entered to download uploaded file.</p>
                    <code>onedayexpire ("delete_at" returns null|on)</code>

                    <p>Upload gets gracefully deleted after 24 hours.</p>
                    <code>remake ("delete_at" returns true|false) **For
                    Images**</code>

                    <p>Re-encodes image, clearing out any attached
                    metadata.</p>
                    <code>{ "status": "success", "data": { "base_url":
                    "https://obscuredfiles.com", "password":
                    "1qfx3tlo46uza", "obscured": false, "requestip":
                    "50.99.72.234", "localhost": false, "torip": false, "link":
                    "https://obscuredfiles.com/?file=x8iWpYIc", "delete_link":
                    "https://obscuredfiles.com/?delete=x8iWpYIc&k=i1SZFsRRNo3T",
                    "file_sha1": "f626e3685fad6f431b96cb96c0f7d3f238ae1aec",
                    "remake": false, "is_image": false, "file_type":
                    "text/plain", "delete_at": "on" } }</code>
                </div>


                <div class="col-sm-12">
                    <h2>Have questions?</h2>


                    <p>If you have any questions you can contact us via email
                    <a href=
                    "admin@obscuredfiles.com">admin@obscuredfiles.com</a>.</p>
                </div>
            </div>
        </div>
    </section>
    <!-- FOOTER -->
    <?php include( "footer.php"); ?><!-- END FOOTER -->
</body>
</html>