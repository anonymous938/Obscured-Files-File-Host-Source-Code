<?php if ($base_url==ONION_SERVICE): ?>
	<form class="formdem" action="<?php echo BALANCED_URL_ONION ?>/index.php/upload/do_upload" enctype="multipart/form-data" method="post">
<?php else: ?>
	<form class="formdem" action="<?php echo BALANCED_URL ?>/index.php/upload/do_upload" enctype="multipart/form-data" method="post">
<?php endif ?>