﻿<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html lang=en>
	<head>
		<meta http-equiv=Content-Type content="text/html; charset=UTF-8">
		<meta name=viewport content="width=device-width, initial-scale=1.0">
		<title>Obscured Files - Partners/Helpers</title>
		<meta name=description content="A couple shout outs to resources and communities that have benefited or made this project possible.">
		<meta name=author content=ObscuredFiles>
		<link href="<?php echo $base_url; ?>/public/css/tidy-un.css" rel="stylesheet">
    	<?php include_once(__DIR__ . "/../../../back/analyticstracking.php") ?>
	</head>
	<body data-target="#navbar-menu">
			<?php include("header.php") ?>
		<section class="home" id=home>
			<div class=container>
				<div class=row>
					<div class="col-sm-12">
					<h2>Partnerships/Helpers</h2>
					<p>This site is quite a unique project. First starting off as a dead simple tool between a small group of friends to share files easily between each other, and now, growing into site that handles thousands of requests daily. While our goal has never changed, make a picture perfect private file sharing host, the way we go about completing that goal has. With so many files being uploaded and shared on a daily basis our core design structure has seen a significant number of changes. From the way we handle files on our servers to the way we serve the files. A lot of what we do now would not be happening without the growing internal community we now have.</p>

					<p>So, on this page, we would like to have a couple shout outs to resources and communities that has benefited this project. Without some of these partners this project wouldn't be as great as it is.</p>
					</div>
				</div>
			</div>
		</section>
		<section class=section id=features>
			<div class=container>
				<div class="row">
					<div class="col-sm-6">
					<h2><a href="https://www.torproject.org/" target="_blank">Tor Project</a></h2>
					<p>Obviously without the tor project and the community and resources that it gives a large part of this project would not exist. We want users to be private. The tor project helps a lot in that sense. No longer do users need to trust when we say we do not store IP addresses. Users have the option to visit using our onion service. They still have access to the same features that the Clearnet side has but also the extra privacy that onion services give. So shout out to these guys, because they are awesome.</p>
					</div>
					<div class="col-sm-6">
					<h2><a href="https://codeigniter.com/" target="_blank">CodeIgniter</a></h2>
					<p>Our original site was made pretty much by hand. It was made to be simple; we didn’t need much. But handling file uploads in that method can leave security holes and exploits. When we found out how types could be spoofed, we shut the site down, and rebuilt it. We rebuilt it on CodeIgniter. Being that it was a server side PHP framework, we could integrate our none changeable database code. Not only was it easy-ish to do but it already has a large community and documentation which helped this transition considerably. It also allowed for new expansions to be integrated with ease. It was a savior framework, without it being there I doubt we would have come back at all.</p>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-6">
					<h2><a href="https://crate.io/" target="_blank"><a href="http://z-o-o-m.eu/index.php" target="_blank">Crate Database</a></h2>
					<p>From our distribution upgrade we needed a highly scalable and available database to be able to distribute all the file requests. Crate does just that. It allows us to scale out from a near impossible problem to a couple simple command lines. We can scale crate to the sky with a 100TB of data and it would still be a powerhouse handling hundreds of thousands of requests. We looked at it for the scalablity and couldn't be more happy.</p>
					</div>
					<div class="col-sm-6">
					<h2><a href="http://z-o-o-m.eu/index.php" target="_blank">File&Image Uploader</a></h2>
					<p>So this one is a little different. A while back couple users told me about this program. It can significantly speed up the upload process on Obscured Files and many other file sharing sites. Coupled with tons of useful features (which we won’t specify here) it makes a worthwhile application for heavy uploaders. Zoom and us had a few talks about how the program operates on the site to make sure of full upload capability. If you find post commands too slow on the up, try this program, we bet you will love it.</p>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-12">
						<h2><a href="https://www.torservers.net/" target="_blank">Torservers</a></h2>
						<p>Not really a partnership, but more of a shout out. Torservers hosts most of the relay points connecting to the onion service side. Without their excellent servers it wouldn't be near as fast as it currently is. So good on them by indirectly helping us.</p>
						</div>
					</div>
				</div>
			</div>
		</section>
    <!-- FOOTER -->
	<?php include( "footer.php"); ?>
    <!-- END FOOTER -->
	</body>
</html>