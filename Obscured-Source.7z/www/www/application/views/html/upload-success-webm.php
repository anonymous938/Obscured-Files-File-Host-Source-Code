<section class="features" id=features>
    <div class=container>
        <div class="row">
            <div class="col-sm-12">
                <div class="row">
    			<?php if (!empty($error)): ?>
					<span class="error"> <?php echo $error ?></span>
				<?php endif ?>
                    <div class="col-sm-6">
                        <h3>Media Link</h3>
                        <code><a href="<?php echo $link; ?>" target="_BLANK"><?php echo $link; ?></a></code>
                        <hr>
                        <p>Upload Information:</p>
                        <?php if ($remake): ?>
			<code>Can't remake Webm.</code>
                        <?php else: ?>
                        <code>Webms are only stored for one hour.</code>
                        <?php endif ?>
			<?php if ($localhost || isset($torip) && $torip): ?>
				<code>File Uploaded Privately [Tor Detected]</code>
			<?php endif ?>
                        <code>Hot Linking is Enabled (But <a href="/public/404.png" target="_BLANK">Not Recommended</a>)</code>
                    </div>

                    <div class="col-sm-6">
                        <h3>View Media</h3>
                        <a href="<?php echo $link; ?>" target="_BLANK"><video autoplay="true" name="<?php echo $file_name; ?>" controls muted><source src="<?php echo $link; ?>" type="video/webm"></video></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>