    <footer class="section bg-gray footer footer-sm">
        <div class="container">

            <div class="row">
                <div class="col-sm-12">
                    <div class="text-center">
                        <a class="footerslogan navbar-brand logo" href="#navbar-menu">
                            <span class="text-uppercase"><b>Skip</b> Censorship</span>
                        </a>

                        <ul class="list-inline menu-list m-t-30">
                            <li><a href="<?php echo $base_url;?>/?partners"> Partnership/Helpers</a>
                            </li>
                            <li><a href="<?php echo $base_url;?>/?donate">Donate</a>
                            </li>
                            <li><a href="<?php echo $base_url;?>/?api" class="btn btn-inverse btn-bordered footer-btn">API Developer Area</a>
                            </li>
                            <li><a href="<?php echo $base_url;?>/?shame"> Shame Wall</a>
                            </li>
                            <li><a href="https://blog.obscuredfiles.com/"> Blog (new)</a>
                            </li>
                        </ul>

                        <p class="text-muted m-b-0"> © Obscured Files 2011 &gt; 2016 - You are on server <b><a href="https://<?php echo CLEAR_ID; ?>.obscuredfiles.com/"><?php echo CLEAR_ID; ?></a></b>.</p>

                    </div>
                </div>
            </div>
            <!-- end row -->

        </div>
    </footer>
