﻿<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html lang=en>
	<head>
		<meta http-equiv=Content-Type content="text/html; charset=UTF-8">
  		<title>Donation</title>
  		<meta name="viewport" content="width=device-width, initial-scale=1">
  		<meta name="description" content="Main Donation Page. Help make us self sustainable! By donating you are keeping your files online longer and making downloads faster!">
		<meta name=author content=ObscuredFiles>
		<link href="<?php echo $base_url; ?>/public/css/tidy-un.css" rel="stylesheet">
    		<?php include_once(__DIR__ . "/../../../back/analyticstracking.php") ?>
	</head>
	<body data-target="#navbar-menu">
			<?php include("header.php") ?>
		<section class="home" id=home>
			<div class=container>
				<div class=row>
					<div class="col-sm-12" style="padding-bottom: 15px;">
					<h2>Donation Area</h2>
					<p>Help make us self sustainable and get an awesome reward. By donating you are keeping your files online longer and making downloads faster! How many servers we have are tied to how much donations we get, if we get more donations we get more servers.</p>
					<p>The cost of a coffee will pay for 1TB of data transfer. Every cent counts. Support us today!</p> 
					</div>
				</div>
			</div>
		</section>
		<section class="section"  id=features>
			<div class=container>
				<div class="row">
					<div class="col-sm-6">
					<h2>Bitcoin</h2>
					<p>You can donate privately via Bitcoin on the address below.</p>
					<pre><a href=bitcoin:1A8dkBN1uM1KBR6PRYznEm2aaMVJHzU8WK>1A8dkBN1uM1KBR6PRYznEm2aaMVJHzU8WK</a></pre>
					<a href="/public/bitcoinadd.png"><img style="max-width:200" src="/public/bitcoinadd.png"></img></a>
					</div>
					<div class="col-sm-6">
					<h2>Ethereum</h2>
					<p>You can donate privately via Ethereum on the address below.</p>
					<pre><a href=eth:0xF3DB70c36b1926c92Be9ed06d625F06f5baEEf75>0xF3DB70c36b1926c92Be9ed06d625F06f5baEEf75</a></pre>
					<a href="/public/ethadd.png"><img style="max-width:200" src="/public/ethadd.png"></img></a>
					</div>
				</div>
				
				<div class="row">
					<div class="col-sm-6">
					<h2>Get A Peek Inside!</h2>
					<p>Gain insider knowledge about the up incoming features and changes we have in store. This includes prerelease designs, funny insider jokes (ever wonder who jeff is?), and even code snippets. Every month has a new package.</p>
					<form class="form-download" action="<?php echo INSIDE_PEEK_URL; ?>/" method="post">
						<center><input type="submit" value="Inside Peek Download ($10 Donation)" name="clear" class="button" style="max-width: 400px;"></center>
					</form>
					</div>
					<div class="col-sm-6">
					<h2>Other Donation Methods</h2>
					<p>Wanna Donate but you have another coin? No problem. </p>

					<b>Just <a href="mailto:admin@obscuredfiles.com">let us know</a>. Any contribution goes a long way.</b>
					</div>
					<div class="col-sm-12" style="padding-top:5px;">
						<p>If you have any questions about donations and what we use them for you can contact the admin at <a href="mailto:admin@obscuredfiles.com">admin@obscuredfiles.com</a>. You can also contact us for other donation ways.</p>
					</div>
				</div><!-- end row -->
				</div><!-- end container -->
		</section>
    <!-- FOOTER -->
	<?php include( "footer.php"); ?>
    <!-- END FOOTER -->
	</body>
</html>
