<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html lang=en>

<head>
	<meta http-equiv=Content-Type content="text/html; charset=UTF-8">
	<meta name=viewport content="width=device-width, initial-scale=1.0">
	<title>Terms and Condidtions</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Terms and Conditions that rule over Obscured Files. Hail Hydra.">
	<link href="<?php echo $base_url; ?>/public/css/tidy-un.css" rel="stylesheet">
	<?php include_once(__DIR__ . "/../../../back/analyticstracking.php") ?>
</head>

<body data-target="#navbar-menu">
			<?php include("header.php") ?>
	<section class="container headingpad home" id=home>
		<div class=row>
			<div class="col-sm-12">
				<h2>Terms and Conditions</h2>
				<p>These are the terms and conditions. Its main propose is to provide understanding and guidance to users of Obscured Files. Being such it will use layman terms and common English slang. </p>
			</div>
		</div>
	</section>
	<section class="section" id=features>
		<div class="container">
			<div class="row">
				<div class="col-sm-12 apilinespace">
					<p>Yo homey, welcome to Obscured Files. Obscured Files is a super-secret and super-private file sharing website, so that you can spread those files to all your hood. It&rsquo;s made to be so simple your half dog half muscle man would be able to use it. When your muscle dog visits the site and uploads those half decent biceps selfies he will know that it will be private and completely anonymous. No one (not even us) will be able to hook back those ripped biceps to his personal computer&rsquo;s location. How&rsquo;s that for awesome?
						<br /> Being that we (Obscured Files) cannot identify and do not have any logs our legal liability for uploaded files are reduced. Oh I mean, yo being that is super-private even we are bullet proof protected from peeping eyes. But, ma gangsta homey, there are still bullets that can blow our shit up. Bullets fired from:</p>
					<ul>
						<li>Copyright lawyers.</li>
						<li>Parents and representing police of abused children.</li>
						<li><strike>Pimps</strike> Porn Actor's Managers.</li>
						<li>Hacking Software, Viruses, etc.</li>
						<li>Overall law enforcement.</li>
						<li>Jeff from down the street.</li>
					</ul>
					<p>So our word: &ldquo;Don&rsquo;t piss off the guys with power.&rdquo;
						<br /> If you&rsquo;re going to anyway, even if we say <a href="http://usatoday30.usatoday.com/tech/news/story/2012-01-19/megaupload-feds-shutdown/52678528/1">don't</a>, at least <a href="/public/e91c0c1cb9bafcf072437e5b17a1366f.pdf">make it private</a> before uploading. </p>
					<p>If your one of the pissed off people above (Other than that piece of shit Jeff) you can <a href="/?abusecenter">find out which ways you can report</a>.</p>
					<p><strong>TL;DR Overestimating the size of your dick is a good way to disappoint people.</strong><p>
				</div>
			</div>
		</div>
	</section>
	<section class="container headingpad home" id=home>
		<div class=row>
			<div class="col-sm-12">
							<h4>BORING BUT NECESSARY STUFF BELOW</h4>
							<h5> 1. Use of service </h5>
							<p>Users are solely responsible for the files that are uploaded. Obscuredfiles.com and those who work with the website can not be held responsible for the material.</p>
							<h5> 2. Files </h5>
							<p>While we try our best to keep all uploads active Obscuredfiles.com has no responsibility to maintain the uploaded files.</p>
							<h5> 3. Terms </h5>
							<p>Uploading is showing your acceptance of the terms and conditions and can therefore be held responsible for illegal and/or Copyright infringement material.</p>
							<h5> 4. Offenses </h5>
							<p>Do not upload anything that is illegal being that illegal files will be removed.</p>
							<h5> 5. Misuse </h5>
							<p>Files with the intention to cause harm to either the website, server, or users will be removed. </p>
							<p>This document was last updated on February 5, 2016</p>

			</div>
		</div>
	</section>
    <!-- FOOTER -->
	<?php include( "footer.php"); ?>
    <!-- END FOOTER -->
</body>
</html>