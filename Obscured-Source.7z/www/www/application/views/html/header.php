		<div class="navbar navbar-custom sticky" role=navigation>
			<div class=container>
				<div class=navbar-header>
					<a href="#navbar-toggle"><button type=button class=navbar-toggle>
					<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAQAAABKfvVzAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAAAmJLR0QAAKqNIzIAAAAJcEhZcwAADdcAAA3XAUIom3gAAAAHdElNRQfgCA4XNh5gRZQzAAAAQUlEQVQ4y2P8z0AaYCJR/WDUwLJAgEQNTO9J1MDQSZoGxsEXDyyLTtDYhkHp6Q4S/bCQRE+w/BMk0YbBF0q01wAAV8YLoT+H7iQAAAAldEVYdGRhdGU6Y3JlYXRlADIwMTYtMDgtMTRUMjM6NTQ6MzArMDI6MDBSIPQ9AAAAJXRFWHRkYXRlOm1vZGlmeQAyMDE2LTA4LTE0VDIzOjU0OjMwKzAyOjAwI31MgQAAABl0RVh0U29mdHdhcmUAd3d3Lmlua3NjYXBlLm9yZ5vuPBoAAAAASUVORK5CYII=">
					</button></a>
					<a class="navbar-brand logo" href="/">
					<span class=fileico></span> 
					<span>Obscured Files</span>
					</a>
				</div>
				<div class="navbar-collapse collapse" id=navbar-menu>
					<ul class="nav navbar-nav navbar-right">
						<li>
							<a href="https://blog.obscuredfiles.com">Blog</a>
						</li>
						<li>
							<a href="<?php echo $base_url; ?>/?donate" class="btn btn-inverse btn-bordered navbar-btn">Donate</a>
						</li>
					</ul>
				</div>
			</div>
		</div>
		<div id="navbar-toggle" class="menudrop-display-block terms target">
			<a class="close" href="#navbar-menu"><h4>x</h4></a>
       			<a href="<?php echo $base_url;?>/?partners" class="menu">Partnership/Helpers</a>
        		<a href="<?php echo $base_url;?>/?donate" class="menu">Donate</a>
        		<a href="<?php echo $base_url;?>/?api" class="menu">API Developer Area</a>
        		<a href="<?php echo $base_url;?>/?shame" class="menu">Shame Wall</a>
        		<a href="https://blog.obscuredfiles.com/" class="menu">Blog (new)</a>        
		</div>