<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html lang=en>
	<head>
			<title>File Download</title>
			<meta http-equiv=Content-Type content="text/html; charset=UTF-8">
			<meta name=viewport content="width=device-width, initial-scale=1.0">
			<meta name=author content=ObscuredFiles>
			<link href="<?php echo $base_url; ?>/public/css/tidy-un.css" rel="stylesheet">
    			<?php include_once(__DIR__ . "/../../back/analyticstracking.php") ?>
			<?php if ($localhost): ?>
			<link rel="dns-prefetch" href="http://<?php echo $hidden; ?>/">
			<?php endif ?>
			<link rel="dns-prefetch" href="<?php echo $server; ?>">
	</head>
		<body data-target="#navbar-menu">
			<?php include("html/header.php") ?>
		<section class="container headingpad home" id=home>
				<div class=row>
					<div class="col-sm-12">
					<h2>Welcome to the Download Page.
						<?php if ($localhost): ?>
							(Onion Service)</h2>
						<?php else: ?>
        						(Clearnet)</h2>
						<?php endif ?>
					<?php if ($base_url=="ONION_SERVICE"): ?>
						<?php if (!empty(ONION_MESSAGE_URL_DOWNLOAD)): ?>
							<a href="<?php echo ONION_MESSAGE_URL_DOWNLOAD ?>" class="marquee marquee-speed-slow marquee-movement-smooth" data-marquee="<?php echo ONION_MESSAGE_DOWNLOAD ?>"></a>
						<?php else: ?>
							<div class="marquee marquee-speed-slow marquee-movement-smooth" data-marquee="<?php echo ONION_MESSAGE_DOWNLOAD ?>"></div>
						<?php endif ?>
					<?php else: ?>
						<?php if (!empty(CLEAR_MESSAGE_URL_DOWNLOAD)): ?>
							<a href="<?php echo CLEAR_MESSAGE_URL_DOWNLOAD ?>" class="marquee marquee-speed-slow marquee-movement-smooth" data-marquee="<?php echo CLEAR_MESSAGE_DOWNLOAD ?>"></a>
						<?php else: ?>
							<h4><?php echo CLEAR_MESSAGE_DOWNLOAD ?></h4>
						<?php endif ?>
					<?php endif ?>

					<p>This page will allow you choose the download method you want. Some areas will not show if certain conditions are not met.</p>
				</div><!--  end row -->
		</section><!-- end home section -->
					
		<section class="features" id=features>
			<div class=container>
						<div class="row">
							<?php if (isset($delete_at)): ?>
								<div class="col-sm-6">
									<span class="info">File marked for deletion.</span>
								</div>
								<div class="col-sm-6">
									<span class="info">Countdown till deletion: <?php echo $delete_at; ?></span>
								</div>
							<?php endif ?>
								
							
								<div class="col-sm-6">
									<code>SHA1: <?php echo $sha1; ?></code>
								</div>
								<div class="col-sm-6">
									<code>Requesting IP: <?php echo $requestip ?> <?php if ($localhost || isset($torip) && $torip): ?>[Tor Node]<?php endif ?></code>
								</div>
<!-- 								<span class="info">A password is required to access this file. Please enter it below.</span> -->
<!-- 								<span class="success">A password is required to access this file. Please enter it below.</span> -->
								<div class="col-sm-12">
								<?php if ($error): ?>
									<span class="error">Incorrect password entered. Please try again.</span>
								<?php elseif (isset($expiretime)): ?>
									<span class="error">File link has expired. Press download again.</span>
								<?php elseif ($protected): ?>
									<span class="warning">A password is required to access this file. Please enter it below.</span>
								<?php endif ?>
								</div>
							<div class="col-sm-12">
								<hr>
							</div>
							<div class="downloadbutton col-sm-6">
								<h3>Clearnet</h3>
								<p>File Delivery Over HTTPS</p>
								<form class="form-download" action="<?php echo $server; ?>/<?php echo $file; ?>" method="post">
									<input type="hidden" name="ft" value="<?php echo $file_token; ?>">
									<input type="hidden" name="lt" value="<?php echo $link_token; ?>">
									<?php if ($protected): ?>
										<input id="passwordInput" name="password" required="" autocomplete="off" autocorrect="off" autocapitalize="off" placeholder="Password Required" type="password">
									<?php else: ?>
										<input id="passwordInputNoPass" disabled placeholder="No Password Needed" autofocus type="password">
									<?php endif ?>
									<input type="submit" value="Clearnet Download" name="clear" class="button">		
								</form>
							</div>
						<?php if ($localhost || isset($torip) && $torip): ?>
							<div class="downloadbutton col-sm-6">
								<script type="text/javascript">document.write('<b><span class="error">You need to have Javascript Disabled to access the Onion Service Download.</span></b>');</script>
								<noscript>
									<?php if (is_null($hidden)): ?>
										<span class="info">File Delivery Server doesn't have a Onion service... :(</span>
									<?php else: ?>
									<h3>Onion Service</h3>
									<p>Super Private File Delivery Inside The Tor Network.</p>
									<form class="form-download" action="http://<?php echo $hidden; ?>/<?php echo $file ?>" method="post">
										<input type="hidden" name="ft" value="<?php echo $file_token; ?>">
										<input type="hidden" name="lt" value="<?php echo $link_token; ?>">
										<?php if ($protected): ?>
											<input id="passwordInput" name="password" required="" autocomplete="off" autocorrect="off" autocapitalize="off" placeholder="Password Required" autofocus type="password">
										<?php else: ?>
											<input id="passwordInputNoPass" disabled placeholder="No Password Needed" autofocus type="password">
										<?php endif ?>
										<input type="submit" value="Onion Service Download" name="clear" class="button">
									</form>			
							<?php endif ?>
							</div>
						<?php endif ?>
							<div class="col-sm-12">
								<p>Find out <a href="/?abusecenter">which ways you can report a bad file</a>.</p>
							</div>
						</div><!-- end row -->
					</div><!-- end col 12 -->
			</div><!--  end container -->
		</section><!-- end features section -->	
    <!-- FOOTER -->
	<?php include( "html/footer.php"); ?>
    <!-- END FOOTER -->
</body>
</html>