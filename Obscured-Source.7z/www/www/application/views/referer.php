﻿<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html lang=en>
	<head>
		<meta http-equiv=Content-Type content="text/html; charset=UTF-8">
		<meta name=viewport content="width=device-width, initial-scale=1.0">
		<title>Bad Referer</title>
		<meta name=author content=ObscuredFiles>
		<link href="<?php echo $base_url; ?>/public/css/tidy-un.css" rel="stylesheet">
    		<?php include_once(__DIR__ . "/../../back/analyticstracking.php") ?>
	</head>
	<body data-target="#navbar-menu">
		<div class="navbar navbar-custom sticky" role=navigation>
			<div class=container>
				<div class=navbar-header>
					<a href="#navbar-toggle"><button type=button class=navbar-toggle>
					<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAQAAABKfvVzAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAAAmJLR0QAAKqNIzIAAAAJcEhZcwAADdcAAA3XAUIom3gAAAAHdElNRQfgCA4XNh5gRZQzAAAAQUlEQVQ4y2P8z0AaYCJR/WDUwLJAgEQNTO9J1MDQSZoGxsEXDyyLTtDYhkHp6Q4S/bCQRE+w/BMk0YbBF0q01wAAV8YLoT+H7iQAAAAldEVYdGRhdGU6Y3JlYXRlADIwMTYtMDgtMTRUMjM6NTQ6MzArMDI6MDBSIPQ9AAAAJXRFWHRkYXRlOm1vZGlmeQAyMDE2LTA4LTE0VDIzOjU0OjMwKzAyOjAwI31MgQAAABl0RVh0U29mdHdhcmUAd3d3Lmlua3NjYXBlLm9yZ5vuPBoAAAAASUVORK5CYII=">
					</button></a>
					<a class="navbar-brand logo" href="/">
					<span class=fileico></span> 
					<span>Obscured Files</span>
					</a>
				</div>
				<div class="navbar-collapse collapse" id=navbar-menu>
					<ul class="nav navbar-nav navbar-right">
						<li>
							<a href="https://blog.obscuredfiles.com">Blog</a>
						</li>
						<li>
							<a href="<?php echo $base_url; ?>/?donate" class="btn btn-inverse btn-bordered navbar-btn">Donate</a>
						</li>
					</ul>
				</div>
			</div>
		</div>
		<div id="navbar-toggle" class="terms target">
			<a class="close" href="#navbar-menu"><h4>x</h4></a>
       			<a href="<?php echo $base_url;?>/?partners" class="menu">Partnership/Helpers</a>
        		<a href="<?php echo $base_url;?>/?donate" class="menu">Donate</a>
        		<a href="<?php echo $base_url;?>/?api" class="menu">API Developer Area</a>
        		<a href="<?php echo $base_url;?>/?shame" class="menu">Shame Wall</a>
        		<a href="https://blog.obscuredfiles.com/" class="menu">Blog (new)</a>        
		</div>
		<section class="container headingpad home" id="home">
				<div class=row>
					<div class="col-sm-12" style="padding-bottom: 15px;">
					<h2>Bad Referer</h2>
					<p>Your referer (<?php echo $referer ?>) has been flagged for commonly linking to files that goes against our <a href=<?php echo $base_url;?>?terms>Terms and Conditions</a>.</p>
					<p>Beware of linked files you download from this referer.</p>					</div>
				</div>
		</section>
		<section class="middlebox section">
			<div class=container>
				<div class=row >
					<div class="col-sm-12">
						<div class="col-sm-6">
							<img src="<?php echo $base_url; ?>/public/referercp.gif">
						</div>
						<div class="col-sm-6">
							<form action="<?php echo $base_url; ?>" method="post">
							<input type="submit" value="Get me out of here!" class="button"></form>
							<form action="<?php echo $base_url . "?file=" . $redirect; ?>" method="post">
							<input type="submit" value="Don't tell me what to do!" class="button"></form>
						<div>	
					</div>
				</div>
			</div>
		</section>
	</body>
</html>
