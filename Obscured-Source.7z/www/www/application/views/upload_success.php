<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html lang=en>
	<head>
			<title>Upload Successful!</title>
			<meta http-equiv=Content-Type content="text/html; charset=UTF-8">
			<meta name=viewport content="width=device-width, initial-scale=1.0">
			<meta name=author content=ObscuredFiles>
			<link href="<?php echo $base_url; ?>/public/css/tidy-un.css" rel="stylesheet">
    			<?php include_once(__DIR__ . "/../../back/analyticstracking.php") ?>
	</head>
	<body data-target="#navbar-menu">
			<?php include("html/header.php") ?>
		<section class="home" id=home>
			<div class=container>
				<div class=row>
					<div class="col-sm-12">
					<h2>Thank you for using Obscured Files.</h2>
					<p>This page will provide you with the upload results based on your initial upload criteria. Some areas will not show if certain conditions are not met.</p>
				</div><!--  end row -->
			</div><!--  end container -->
		</section>
				<div class="content">
					<?php if ($is_image): ?>
						<?php if ($file_type !== 'video/webm'): ?>
							<?php include_once(__DIR__ . "/html/upload-success-img.php") ?>
						<?php else: ?>
							<?php include_once(__DIR__ . "/html/upload-success-webm.php") ?>
						<?php endif ?>
					<?php else: ?>
						<?php include_once(__DIR__ . "/html/upload-success.php") ?>
					<?php endif ?>
			</div>
		</div>
</center>
</body>
</html>
