<?php
switch($_SERVER['QUERY_STRING']) {
	case 'terms':
		include("html/terms.php");
		die;
	break;
	case 'abusecenter':
		include("html/abusecenter.php");
		die;
	break;
	case 'privacy':
		include("html/privacy.php");
		die;
	break;
	case 'partners':
		include("html/partners.php");
		die;
	break;
	case 'api':
		include("html/api.php");
		die;
	break;
	case 'donate':
		include("html/donate.php");
		die;
	break;
	case 'shame':
		include("html/shame.php");
		die;
	break;
}
?>

