<?php

defined('BASEPATH') OR exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| Cluster configuration
|--------------------------------------------------------------------------
|
| Cluster-wide configuration values as well as membership to aid in routing
| of uploads and downloads.
|
*/

$config = [
	// Servers is an array of information about each server keyed by the "name"
	// of the server. The "names" are arbitrary and should only ever be used
	// internally. 
	'servers' => [
		's1' => [
			'ip' => '37.59.52.218',
			'clear_addr' => 'https://s1.obscuredfiles.com',
			'hidden_addr' => 'obscuredtzevzthp.onion',
		],	
		'code' => [
			'ip' => '192.99.100.14',
			'clear_addr' => 'https://code.obscuredfiles.com',
			'hidden_addr' => 'obscuredzzi7wbuy.onion',
		],
		'test' => [
			'ip' => '149.56.14.160',
			'clear_addr' => 'https://test.obscuredfiles.com',
			'hidden_addr' => null,
		],
	],
];