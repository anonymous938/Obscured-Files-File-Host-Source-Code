<?php
defined('BASEPATH') OR exit('No direct script access allowed');

defined('CLEAR_ID')		OR define('CLEAR_ID',				's1');
defined('CLEAR_ID_URL')		OR define('CLEAR_ID_URL',			'https://s1.obscuredfiles.com');

defined('ONION_SERVICE')	OR define('ONION_SERVICE',			'http://obscuredtzevzthp.onion');
defined('ONION_SERVICE_BODY')	OR define('ONION_SERVICE_BODY',			'obscuredtzevzthp');

defined('OFFLINE')		OR define('OFFLINE',				false);
defined('UPLOAD_OFFLINE')	OR define('UPLOAD_OFFLINE',			false);
defined('BALANCED')		OR define('BALANCED',				false);
defined('BALANCED_URL')		OR define('BALANCED_URL',			'https://s2.obscuredfiles.com');
defined('BALANCED_URL_ONION')	OR define('BALANCED_URL_ONION',			'http://obscured2s5avbsd.onion');