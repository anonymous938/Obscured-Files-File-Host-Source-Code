<?php 
defined('INSIDE_PEEK_URL')	OR define('INSIDE_PEEK_URL',			'');

defined('CLEAR_MESSAGE_URL')	OR define('CLEAR_MESSAGE_URL',			'https://blog.obscuredfiles.com/why-is-an-xss-alert-showing/');
defined('ONION_MESSAGE_URL')	OR define('ONION_MESSAGE_URL',			'https://blog.obscuredfiles.com/why-is-an-xss-alert-showing/');

defined('CLEAR_MESSAGE_URL_DOWNLOAD')	OR define('CLEAR_MESSAGE_URL_DOWNLOAD',	'');
defined('ONION_MESSAGE_URL_DOWNLOAD')	OR define('ONION_MESSAGE_URL_DOWNLOAD',	'');

defined('FILENOTFOUND_MESSAGE')	OR define('FILENOTFOUND_MESSAGE',		'The file you are looking for does not, has not, will not, might not, or must not exist.');
defined('REQUEST_INVALID')	OR define('REQUEST_INVALID',		'Your request is invalid. Make sure that you are using <a href=\"https://obscuredfiles.com/\" target=\"_blank\">https://obscuredfiles.com/</a> or <a href=\"http://obscuredtzevzthp.onion/\" target=\"_blank\">http://obscuredtzevzthp.onion/</a>.');
defined('CLEAR_MESSAGE')	OR define('CLEAR_MESSAGE',			'NoScript is making an XSS alert. Click here to find out why.');
defined('OFFLINE_MESSAGE')	OR define('OFFLINE_MESSAGE',			'Currently down for a service update. <p>Keep updated on our <a href="https://twitter.com/obscuredfiles">twitter account (@obscuredfiles)</a>.');
defined('ABUSE_MESSAGE')	OR define('ABUSE_MESSAGE',			'Uploaded file has been reported before as an abused file. File has been disgarded.');


defined('CLEAR_MESSAGE_DOWNLOAD')	OR define('CLEAR_MESSAGE_DOWNLOAD',	'<a href="https://blog.obscuredfiles.com/why-is-an-xss-alert-showing/">Wondering about that XSS alert? Click here to find out why it shows.</a>');
defined('OFFLINE_MESSAGE_DOWNLOAD')	OR define('OFFLINE_MESSAGE_DOWNLOAD',	'<a href="https://blog.obscuredfiles.com/why-is-an-xss-alert-showing/">Wondering about that XSS alert? Click here to find out why it shows.</a>');
