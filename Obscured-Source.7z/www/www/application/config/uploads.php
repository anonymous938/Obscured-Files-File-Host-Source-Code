<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| File upload and Site directory configuration
|--------------------------------------------------------------------------
|
| These have been set up as constants so that they are universally 
| accessible by both framework code as well as ad-hoc scripts
|
*/
defined('UPLOAD_BASE_DIR')	OR define('UPLOAD_BASE_DIR',			'/var/www/');
defined('FILE_DIR')		OR define('FILE_DIR',				'ul/');
defined('DAY_FILE_DIR')		OR define('DAY_FILE_DIR',			'day/');
defined('IMAGE_DIR')		OR define('IMAGE_DIR',				'www/pic/');
defined('BACK_DIR')		OR define('BACK_DIR',				'www/back/');
defined('DELETE_HMAC_KEY')	OR define('DELETE_HMAC_KEY',			'BvMNyQSfhZ6gzLOf3I');
defined('ABUSE_USER')	OR define('ABUSE_USER',			'abuse');
defined('ABUSE_PASS')	OR define('ABUSE_PASS',			'password');
defined('DEFAULT_CLEAR_URL')	OR define('DEFAULT_CLEAR_URL',			'https://obscuredfiles.com');
defined('DEFAULT_ONION_URL')	OR define('DEFAULT_ONION_URL',			'http://obscuredtzevzthp.onion');

//Site Configuration
include('site.php');

//Messages
include('messages.php');

$config = [];