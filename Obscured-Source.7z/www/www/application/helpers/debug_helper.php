<?php

if ( ! function_exists('dump')) {
	/** 
	 * Debug Helper * 
	 * Outputs the given variable(s) with formatting and location * 
	 * Source: https://philsturgeon.uk/php/2010/09/28/power-dump-php-applications/
	 * 
	 * @access public 
	 * @param mixed variables to be output 
	 */
	function dump() { 
		list($callee) = debug_backtrace(); 
		$arguments = func_get_args(); 
		$total_arguments = count($arguments); 
		echo '<fieldset style="background: #fefefe !important; border:2px red solid; padding:5px">'; 
		echo '<legend style="background:lightgrey; padding:5px;">'
			.$callee['file'].' @ line: '.$callee['line'].'</legend><pre>'; 
		$i = 0; 
		foreach ($arguments as $argument) { 
			echo '<br/><strong>Debug #'.(++$i).' of '.$total_arguments.'</strong>: '; 
			var_dump($argument); 

		} 
		echo "</pre>"; echo "</fieldset>";
	}
}

if ( ! function_exists('dd')) {
	/**
	 * @function dd
	 * 
	 * Same as `dump()` only die afterwards.
	 */
	function dd() { 
		list($callee) = debug_backtrace(); 
		$arguments = func_get_args(); 
		$total_arguments = count($arguments); 
		echo '<fieldset style="background: #fefefe !important; border:2px red solid; padding:5px">'; 
		echo '<legend style="background:lightgrey; padding:5px;">'
			.$callee['file'].' @ line: '.$callee['line'].'</legend><pre>'; 
		$i = 0; 
		foreach ($arguments as $argument) { 
			echo '<br/><strong>Debug #'.(++$i).' of '.$total_arguments.'</strong>: '; 
			var_dump($argument); 

		} 
		echo "</pre>"; echo "</fieldset>";
		die();
	}
}