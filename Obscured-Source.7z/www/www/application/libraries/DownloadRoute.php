<?php if ( ! defined('BASEPATH')) { exit('No direct script access allowed'); }

use GuzzleHttp\Client;

// TODO: Find a way to either autoload this or load it through the CI system
require_once FCPATH.'/internal.php';

/**
 * @class DownloadRoute
 * 
 * This class is responsible for find the appropriate server to handle a download
 * request. Any logic to account for preferences, load-balancing, availability,
 * etc should ideally be the responsiblity of this class.
 * 
 * TODO: At present because the location of files isn't being recorded in the
 * database, this is being discovered by HTTP probes. Whilst this may stay true,
 * recording the location in the database would probably allow for fewer external
 * HTTP requests and lower client-side latencies.
 * 
 * TODO: Avoid creating download routes to servers that aren't online.
 */
class DownloadRoute {
		
	/**
	 * The degree to which to mistrust the database information about file 
	 * location. Approximately this fraction of the time, the location 
	 * information in the database will be checked for accuracy.
	 * 
	 * @param float
	 */
	const DEFAULT_PARANOIA = 0.1;
	
	/**
	 * Default timeout on HTTP requests
	 * 
	 * @var float
	 */
	private static $TIMEOUT = 2;
	
	/**
	 * The details of the server on which the download may be found
	 * 
	 * @var array
	 */
	private $server = null;
	
	/**
	 * @var \GuzzleHttp\Client
	 */
	private static $client = null;
	
	/**
	 * Construct a route.
	 * 
	 * The route takes as its parameters
	 * 
	 * @param array $params The parameter array has the following keys:
	 *		filepath		- the absolute path to the file
	 *		sha1			- the SHA1 digest of the file
	 *		own_ip		- the IP address of the server as far as is known
	 *		servers		- an array of the servers in the cluster in the format
	 *						of the servers entry in the file "config/cluster".
	 *		(prefer)		- the name of the preferred server
	 *		(paranoia)	- roughy how often to confirm file location information
	 */
	public function __construct(array $params) {
		
		$paranoia = array_key_exists('paranoia', $params) ? 
			$params['paranoia'] : self::DEFAULT_PARANOIA;
		
		$own_addr = $this->get_own_addr($params['servers'], $params['own_ip']);
		
		// Build up a list of servers to try. This list should be kept duplicate
		// free to avoid generating unnecessary load on the servers.
		$pref = array_key_exists('prefer', $params) ? $params['prefer'] : null;
		$candidates = $this->get_candidates($params['servers'], $params['own_ip'], $pref);
		
		// Loop through each server checking whether it has the file
		$this->find_host_server(
			$candidates, $own_addr, $params['upload'], $paranoia);
	}
	
	/**
	 * Generate a list of candidate locations for the file, with most preferred
	 * servers first.
	 * 
	 * @param array		$servers
	 * @param string	$own_ip
	 * @param string	$preferred	The name of the preferred server
	 * 
	 * @return array
	 */
	private function get_candidates(array $servers, $own_ip, $preferred = null) {
		$candidates = [];
		
		// Check preference. If available, candidate is first in line.
		if ($preferred && array_key_exists($preferred, $servers)) {
			$candidates[$servers[$preferred]['clear_addr']] = $servers[$preferred];
		}
		
		// Self is next in line
		$own_name = null;
		foreach ($servers as $name => $details) {
			if ($own_ip == $details['ip']) {
				$own_name = $name;
				break;
			}
		}
		
		if ( ! array_key_exists($own_name, $candidates) && $own_name) {
			$candidates[$servers[$own_name]['clear_addr']] = $servers[$own_name];
		}
		
		// Then add every other server in arbitrary order to spread load
		$all_servers = array_keys($servers);
		shuffle($all_servers);
		foreach($all_servers as $server) {
			if ( ! in_array($server, $candidates)) {
				$candidates[$servers[$server]['clear_addr']] = $servers[$server];
			}
		}

		return $candidates;
	}
	
	/**
	 * Find the address of the server that will be used as the host for the 
	 * download.
	 * 
	 * @param array			$candidates
	 * @param type			$own_addr
	 * @param UploadInfo		$upload
	 * @param float			$paranoia
	 */
	private function find_host_server(
			array $candidates, $own_addr, UploadInfo $upload, $paranoia) 
	{	
		$locations = $upload->locations ?: [];
		$trust_db = (rand(0, 1000) / 1000) > $paranoia;
		foreach($candidates as $server => $details) {
			
			$has_it = false;
			$ip = $details['ip'];
			
			// We choose to believe what the DB says
			if ($trust_db && in_array($ip, $locations)) {
				$has_it = true;
			}
			elseif ($server == $own_addr) {
				$has_it = $this->on_current_server($upload);
			}
			else {
				// Ask the server
				$has_it = $this->check_server($server, $upload);
			}
			
			if ($has_it) {
				// Was this in the DB? If not, store it for next time
				in_array($ip, $locations) ||
					$upload->registry->record_location($upload->id, $ip);
				
				$this->server = $details;
				return;
			}
			elseif (in_array($ip, $locations)) {
				// The DB says this server had it? We were right not to trust it
				$upload->registry->record_location($upload->id, null, true);
			}
		}
	}
	
	/**
	 * Check whether the given upload is present on this server.
	 * 
	 * @param UploadInfo $upload
	 * @return boolean
	 */
	private function on_current_server(UploadInfo $upload) {
		if ( ! file_exists($upload->filepath)) {
			return false;
		}
		
		if (sha1_file($upload->filepath) != $upload->sha1) {
			return false;
		}
		
		return true;
	}
	
	/**
	 * Check whether a given server has the file or not
	 * 
	 * @param string		$address Address of the server to check
	 * @param UploadInfo		$upload
	 * 
	 * @return boolean
	 */
	private function check_server($address, UploadInfo $upload) {
		
		self::$client = self::$client ?: new Client(['defaults' => [
			'timeout' => self::$TIMEOUT, 
			'connect_timeout' => self::$TIMEOUT
		]]);
		$probe_msg = new FileProbeMessage($upload->filepath, $upload->sha1);
		
		try {
			$resp = self::$client->get(
				$address.'/internal.php?have_file='.$probe_msg->encode(),
				['headers' => ['Connection: close']]);
		}
		catch (Exception $e) {
			// We don't really know how to actually handle this right
			// now so we'll just say its not on the server.
			return false;
		}

		if ($resp->getStatusCode() != 200) { 
			return false;
		}

		return $resp && $resp->getBody()->getContents() == '1';
	}
	
	/**
	 * Get the server's own address from the mapping of addresses to IP addreses.
	 * Accounts for the possibility of not knowing the actual public IP address
	 * 
	 * @param array		$servers
	 * @param string	$own_ip
	 */
	private function get_own_addr(array $servers, $own_ip) {
		// If we haven't been given our own IP address in a usable form
		if (is_null($own_ip) || empty(trim($own_ip)) || in_array($own_ip, ['127.0.0.1', '::1'])) {
			$own_ip = $this->get_own_ip();
		}

		foreach($servers as $name => $server) {
			if ($server['ip'] == $own_ip) {
				return $server['clear_addr'];
			}
		}

		return 'localhost';	// Best we can do
	}
	
	/**
	 * Get the download server for the file. Returns null if one
	 * could not be found.
	 * 
	 * @return string
	 */
	public function server() {
		return $this->server;
	}
	
	/**
	 * Get the public IP address of the server running this script.
	 *
	 * @return string IP address
	 */
	private function get_own_ip() {
		$sock = socket_create(AF_INET, SOCK_DGRAM, SOL_UDP);
		socket_connect($sock, '8.8.8.8', 80); // IP of Google public DNS server

		$addr = '';
		socket_getsockname($sock, $addr);
		socket_shutdown($sock);
		socket_close($sock);

		return $addr;
	}
}
