<?php

require_once(__DIR__ . '/../config/database.php');

use Crate\PDO\PDO as PDO;

/**
 * @class CrateStore
 * 
 * Class for simpligfying the task of interacting with Crate
 */
class CrateStore {
	
	/**
	 * The name of the schema in which the records table is stored
	 * 
	 * @var string
	 */
	private $database = '';
	
	/**
	 * A Crate PDO instance that may be used for queries
	 * 
	 * @var Crate\PDO\PDO
	 */
	private $pdo = null;
	
	public function __construct() {
		global $db;
		$db_conf = $db['default'];
		$dsn = $db_conf['dsn'];
		if (empty($dsn)) {
			$ports = is_array($db_conf['port']) ? $db_conf['port'] : [$db_conf['port'],];
			$dsn_parts = [];
			foreach($ports as $port) {
				$dsn_parts[] = $db_conf['hostname'].':'.$port;
			}
			$dsn = 'crate:' . implode(',', $dsn_parts);
		}

		$this->pdo = new PDO($dsn, null, null, null);
		$this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

		$this->database = $db_conf['database'];
	}
	
	/**
	 * Insert a row into Crate
	 * 
	 * @param string $table Name of table to insert into
	 * @param array $row Data to insert
	 * 
	 * @return bool
	 */
	public function insert($table, $row) 
	{	
		$full_table_name = $this->database . '.' . $table;
		$stmt = $this->pdo->prepare(
				'INSERT INTO ' . $full_table_name
				. ' (' . implode(',', array_keys($row)) . ')'
				. ' VALUES (:' . implode(',:', array_keys($row)) . ')');

		// Create copy of "row" with the keys prefixed by a colon
		$_row = [];
		foreach ($row as $col => $val) {
			$_row[':' . $col] = $val;
		}

		return $stmt->execute($_row);
	}

	/**
	 * Select rows from a table by a WHERE clause
	 * 
	 * @param string	$table
	 * @param array		$where
	 * @param int		$limit
	 * 
	 * @return array Each result in associated array format
	 */
	public function select($table, $where = null, $limit = null)
	{
		$sql = 'SELECT * FROM '. $this->database . '.' . $table;
		if (is_array($where)) {
			$sql .= $this->condition_string($where);
		}
		if (!is_null($limit)) {
			$sql .= ' LIMIT ' . intval($limit);
		}
		
		$stmt = $this->pdo->prepare($sql);
		$stmt->execute($this->param_array($where));

		return array_map(function ($arr) {
				$obj = new stdClass;
				foreach($arr as $k => $v) {
					$obj->{$k} = $v;
				}
				return $obj;
			},
			$stmt->fetchAll(PDO::FETCH_ASSOC)
		);
	}
	
	/**
	 * Select rows from a table by a WHERE clause
	 * 
	 * @param string	$table
	 * @param array		$where
	 * 
	 * @return int
	 */
	public function delete($table, $where = null) {

		$sql = 'DELETE FROM ' . $this->database . '.' . $table;
		if (is_array($where))	{ 
			$sql .= $this->condition_string($where); 
		}
		
		$stmt = $this->pdo->prepare($sql);
		
		return $stmt->execute($this->param_array($where));
	}
	
	/**
	 * Update the database
	 * 
	 * @param string $table
	 * @param array $where
	 * @param array $values
	 * 
	 * @return int
	 */
	public function update($table, array $where, array $values) {
		$sql = 'UPDATE ' . $this->database . '.' . $table . ' SET ';
		
		$updates = array_map(
			function ($key) use ($values) {
				if (is_int($key)) {
					return $values[$key];
				}
				return $key . '=:u_' . $key;
			}, 
			array_keys($values)
		);
		$sql .= implode(', ', $updates);

		if (is_array($where)) {
			$sql .= $this->condition_string($where);
		}

		$stmt = $this->pdo->prepare($sql);
		
		return $stmt->execute(
			array_merge(
				$this->param_array($where), $this->param_array($values, 'u_'))
		);
	}

	/**
	 * Create a condition SQL string from a "$where" array
	 * 
	 * @return string
	 */
	protected function condition_string(array $where)
	{
		$sql = ' WHERE ';
		$conditions = array_map(
				function ($key) use ($where) {
			if (is_int($key)) {
				return $where[$key];
			}
			return $key . '=:' . $key;
		}, array_keys($where)
		);
		$sql .= implode(' AND ', $conditions);
		
		return $sql;
	}
	
	/**
	 * Create a parameters array from a "$where" array
	 * 
	 * @param array $where
	 * @param string $prefix
	 */
	protected function param_array(array $where, $prefix = '') 
	{	
		$params = [];
		foreach ($where as $col => $val) {
			if (is_int($col)) {
				continue;
			}
			$params[':' . $prefix . $col] = $val;
		}
		return $params;
	}
	
}
