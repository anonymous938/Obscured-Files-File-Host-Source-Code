<?php if ( ! defined('BASEPATH')) { exit('No direct script access allowed'); }

use GuzzleHttp\Client;

// TODO: Find a way to either autoload this or load it through the CI system
require_once FCPATH.'/internal.php';

// Class needs the CrateStore class. If the class is not provided with this, it
// will try to load it from the same directory. Probably not the best way to do
// this.

/**
 * @class UploadRegistry
 * 
 * The registry is responsible for recording uploads, maintaining information
 * about them and providing useful information about them in a convenient form.
 */
class UploadRegistry {

	/**
	 * The name of the table used to maintain upload records
	 * 
	 * @var string
	 */
	private static $UPLOADS_TABLE = 'uploads_efKz69bw8';
	
	/**
	 * The name of the table used to maintain records of files reported as abusive
	 * 
	 * @var string
	 */
	private static $ABUSIVE_FILE_TABLE = 'abusive_files';
	
	/**
	 * @var CrateStore
	 */
	private $crate = null;
	
	/**
	 * CodeIgniter class loader
	 * 
	 * @var CI_Loader
	 */
	private $load = null;
	
	/**
	 * @var \GuzzleHttp\Client
	 */
	private static $client = null;
	
	/**
	 * Default timeout on HTTP requests
	 * 
	 * @var float
	 */
	private static $TIMEOUT = 2;
	
	/**
	 * @var string
	 */
	private $abuse_msg = 
		"Uploaded file has been reported before as an abused file. File has been disgarded.";
	
	/**
	 * Base configuration for the uploads library
	 * 
	 * @return array
	 */
	private static function get_base_upload_config() {
		return [
			'image_path' => UPLOAD_BASE_DIR . IMAGE_DIR,
			'allowed_types' => 
				'gif|jpg|jpeg|png|tar|webm|zip|rar|gz|torrent|txt|7z|key|asc|001|002|003|004|005|006|007|008|009|010',
			'max_size' => 500000,
			'max_width' => 0,
			'max_height' => 0,
			'encrypt_name' => true,
			'overwrite' => true,
		];
	}
	
	/**
	 * @param array			$params
	 * @param CrateStore	$crate
	 */
	public function __construct(array $params, CrateStore $crate = null) {
		if (is_null($crate)) {
			require_once 'CrateStore.php';
			$crate = new CrateStore();
		}
		$this->crate = $crate;
		$this->load = $params['loader'];
	}
	
	/**
	 * Add a new entry to the UploadRegistry. 
	 * 
	 * @param UploadRequest $request
	 * @return UploadResult
	 */
	public function add(UploadRequest $request) {

		$upload = $this->init_upload($request);
		if ( ! $upload->do_upload()) {
			return new UploadResult(null, $upload->display_errors());
		}
		$data = $upload->data();
		
		// Check if file is on the abuse list
		$data['sha1'] = sha1_file($data['full_path']);
		if ($this->is_abusive($data)) {
			return new UploadResult(null, $this->abuse_msg);
		}
		
		// Generate 8 char identifier
		$data['file_id'] = $this->random_string();
		
		if ($request->has_password) {
			$data['password'] = base_convert(
				bin2hex(openssl_random_pseudo_bytes(8)), 16, 36);
		}
		
		// Save the relevant details of the upload in the database
		$row = $this->prepare_row($data, $request);
		if ( ! $data['is_image']) {
			if ( ! $this->crate->insert(self::$UPLOADS_TABLE, $row)) {
				return new UploadResult(null, 'Error saving record to database.');
			}

			$data['expire_in_24h'] = $request->expire_in_24h;
		}
		$data['delete_code'] = $this->generate_delete_code($row);
		
		return new UploadResult($data);
	}
	
	/**
	 * Get information about a file
	 * 
	 * @param string $id
	 * @return UploadInfo
	 */
	public function get($id) {
		
		// Look up the file from the database
		$result = $this->crate->select(self::$UPLOADS_TABLE, ['id' => $id], 1);
		
		if ( ! count($result)) {
			return new UploadInfo($this, $id);
		}
		$row = $result[0];

		// Lazy delete explicity expired files
		if ($row->delete_at && ($row->delete_at < time())) {
			$this->delete($id);
			return new UploadInfo($this, $id);
		}
		
		$file_dir = $this->upload_dir((bool) $row->delete_at, $row->uploaded_at);
		$filepath = $file_dir . basename($row->random_name);

		$password_protected = ! is_null($row->password);
		return new UploadInfo(
			$this, $id, $filepath, $row->sha1, $password_protected, 
			$row->location, $row->delete_at);
	}
	
	/**
	 * Delete an upload
	 * 
	 * @param string $id
	 */
	public function delete($id) {
		
		// Look up the file from the database
		$result= $this->crate->select(self::$UPLOADS_TABLE, ['id' => $id], 1);		
		if ( ! count($result)) {
			return;
		}
		$row = $result[0];

		// Get number of references to the same file in the DB. We use the 
		// delete_at condition to delete either the file in the normal storage
		// or the file in 24 storage independently.
		$references = $this->crate->select(
			self::$UPLOADS_TABLE, 
			[
				'sha1' => $row->sha1, 
				'delete_at IS ' . ($row->delete_at ? 'NOT NULL' : 'NULL')
			]
		);
		$no_references = count($references);
		
		// Only delete file on disk if this is the only reference to the file
		if ($no_references <= 1)
		{
			$filepath = upload_path($row);
			
			// Delete the file on disk
			unlink($filepath);
		}
		
		// And the record of it...
		$this->crate->delete(self::$UPLOADS_TABLE, ['id' => $row->id]);
	}
	
	/**
	 * Delete all traces of the upload with the given ID. Unlike the method
	 * above, this will delete all files and records with the same hash. This 
	 * means that files may be deleted on behalf of other individuals so this
	 * should be used with caution.
	 * 
	 * TODO: Return a result to indicate whether deleting the file(s) was 
	 * successful
	 * 
	 * @param string	$id
	 * @param array		$servers
	 * @param boolean	$delete_refs	Whether database entries should be 
	 *									removed	as well.
	 * 
	 * @return boolean
	 */
	public function nuke($id, array $servers, $delete_refs = true) {
		
		// Look up the file from the database
		$result= $this->crate->select(self::$UPLOADS_TABLE, ['id' => $id], 1);		
		if ( ! count($result)) {
			return false;
		}
		$sha1 = $result[0]->sha1;
		
		// Find all records with the same hash
		$results = $this->crate->select(self::$UPLOADS_TABLE, ['sha1' => $sha1]);
		$paths = [];
		foreach($results as $row) {
			$filepath = $this->upload_path($row);
			in_array($filepath, $paths) || ($paths[] = $filepath);
		}
		
		// Issue deletes for the given paths to all the servers
		foreach($paths as $path) {
			foreach($servers as $server) {
				$this->request_delete($server['clear_addr'], $path, $sha1);
			}
		}
		
		// Delete the database records for each instance
		foreach($results as $row) {
			$delete_refs && $this->crate->delete(self::$UPLOADS_TABLE, ['id' => $row->id]);
		}
		
		return true;
	}
	
	/**
	 * Return the absolute file path to an image
	 * 
	 * @param string $filename
	 */
	public function image_path($filename) {
		$config = self::get_base_upload_config();
		return $config['image_path'].$filename;
	}
	
	/**
	 * Set a location in which the given file can be found
	 * 
	 * @param string	$file_id
	 * @param string	$location
	 * @param boolean	$exclusive (optional) Whether the location given should
	 *								be the only one recorded
	 */
	public function record_location($file_id, $location = null, $exclusive = false) {
		$locations = [];
		$location && $locations[] = $location;
		
		if ( ! $exclusive) {
			$result = $this->crate->select(self::$UPLOADS_TABLE, ['id' => $file_id], 1);
			// TODO: Check whether anything came back at all
			
			$row = $result[0];
			$locations = array_values(array_unique(
				array_merge($locations, $row->location ?: [])));
		}
		
		$this->crate->update(
			self::$UPLOADS_TABLE, 
			['id' => $file_id], 
			['location' => $locations]);
	}
	
	/**
	 * Which directory to upload the file to
	 * 
	 * @param boolean	$day_file
	 * @param int		$timestamp
	 * 
	 * @return string
	 */
	public function upload_dir($day_file, $timestamp = null) {
		if ($day_file) {
			return UPLOAD_BASE_DIR . DAY_FILE_DIR;
		}
		else {
			$date_dir = '/' . date("m.d.Y", $timestamp ?: time()) . '/';
			if (!file_exists(UPLOAD_BASE_DIR . FILE_DIR . $date_dir)) {
				mkdir(UPLOAD_BASE_DIR . FILE_DIR . $date_dir);
			}
			return UPLOAD_BASE_DIR . FILE_DIR . $date_dir;
		}
	}
	
	/**
	 * Report that the file with the given hash (currently SHA1) is abusive. This
	 * will be noted for later uploads.
	 * 
	 * @param string $hash
	 */
	public function report_abusive_file($hash) {
		$row = ['sha1' => $hash, 'reported_at' => time()];
		return $this->crate->insert(self::$ABUSIVE_FILE_TABLE, $row);
	}
	
	/**
	 * Given a result row, return the filepath for a file.
	 * 
	 * @param stdClass $row
	 * @return string
	 */
	protected function upload_path(stdClass $row) {
		$file_dir = $this->upload_dir((bool) $row->delete_at, $row->uploaded_at);
		return $file_dir . basename($row->random_name);
	}
	
	/**
	 * Prepare the row that will be inserted into Crate
	 *  
	 * @param array			$data
	 * @param UploadRequest $request
	 * 
	 * @return array
	 */
	protected function prepare_row(array $data, UploadRequest $request) {
		$row = [
			'id'			=> $data['file_id'],
			'original_name' => $data['orig_name'],
			'random_name'	=> $data['file_name'],
			'sha1'			=> $data['sha1'],
			'uploaded_at'	=> time(),
		];

		if ($request->has_password) {
			$row['password'] = password_hash($data['password'], PASSWORD_DEFAULT);
		}
		
		if ($request->obscure_name) {
			$row['original_name'] = $this->random_string() . $data['file_ext'];
		}

		// Set delete at time if short expiry requested
		if ($request->expire_in_24h) {
			$row['delete_at'] = time() + 24 * 60 * 60;
		}
		
		return $row;
	}
	
	/**
	 * Generate a random string
	 * 
	 * @param int $len
	 * @return string
	 */
	protected function random_string($len = 8) {
		$alphabet = 
			'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
		return substr(str_shuffle($alphabet), 0, $len);
	}
	
	/**
	 * 
	 * @param string $address
	 * @param string $filepath
	 * @param string $hash
	 * 
	 * @return boolean
	 */
	protected function request_delete($address, $filepath, $hash) {
		self::$client = self::$client ?: new Client(['defaults' => [
			'timeout' => self::$TIMEOUT, 'connect_timeout' => self::$TIMEOUT
		]]);
		$probe_msg = new FileProbeMessage($filepath, $hash);
		
		try {
			$resp = self::$client->get(
				$address.'/internal.php?delete_file='.$probe_msg->encode(),
				['headers' => ['Connection: close']]);
		}
		catch (Exception $e) {
			// We don't really know how to actually handle this right
			// now so we'll just say its not on the server.
			return false;
		}

		if ($resp->getStatusCode() != 200) { 
			return false;
		}

		return $resp && ($resp->getBody()->getContents() == '1');
	}
	
	/**
	 * Generate a delete code for an upload based on some information about it.
	 * The code is derived using an HMAC and then filtered and truncated to give
	 * a 12 character string.
	 * 
	 * @param array $row
	 * 
	 * @return string
	 */
	protected function generate_delete_code(array $row) 
	{
		$id = $row['id']; 
		$sha1 = $row['sha1']; 
		$created_at = $row['uploaded_at'];
		
		// Create an HMAC of the given information using the MD5 digest as well
		// as the secret key for these. 
		// WARNING: Changing this key will render old delete links useless.
		$hmac = hash_hmac(
			'md5', implode('|', [$id, $sha1, $created_at]), DELETE_HMAC_KEY, true);
		
		// Use base64 encoding so we get the a 64 char character space (not hex)
		$base64 = base64_encode($hmac);
		
		// Remove "+" and "/" characters (mess with URLs)
		$base62 = str_replace(['/', '+'], ['', ''], $base64);
		
		// Return the truncated version
		return substr($base62, 0, 12);
	}
	
	/**
	 * Get a CI_Upload instance
	 * 
	 * @param UploadRequest $request
	 * @return CI_Upload
	 */
	protected function init_upload(UploadRequest $request) {
		$config = $this->get_base_upload_config();
		$config['upload_path'] = $this->upload_dir($request->expire_in_24h);
		$config['obscured'] = $request->obscure_name;
		$this->load->library('upload');
		return new CI_Upload($config);
	}
	
	/**
	 * Check whether the file has been reported to be abusive
	 * 
	 * @param array $data
	 * @return boolean
	 */
	protected function is_abusive(array $data) {
		
		// Look up the file from the database
		$result = $this->crate->select(
			self::$ABUSIVE_FILE_TABLE, ['sha1' => $data['sha1']], 1);
		return count($result) > 0;
	}
}


class UploadRequest {
	public $obscure_name = false;
	public $expire_in_24h = false;
	public $has_password = false;
	public $remake_image = false;
	
	public function __set($name, $value) {
		throw new Exception("Variable ".$name." has not been set.", 1);
	}
}


class UploadResult {
	
	private $error = null;
	private $success = false;
	private $data = [];
	
	/**
	 * 
	 * @param array		$data
	 * @param string	$error
	 */
	public function __construct(array $data = null, $error = null) {
		$this->success = ! is_null($data);
		$this->error = $error;
		$this->data = $data;
	}
	
	/**
	 * Where or not the upload worked
	 * 
	 * @return boolean
	 */
	public function good() {
		return $this->success;
	}
	
	/**
	 * A string describing why the upload wasn't successful
	 * 
	 * @return string|null
	 */
	public function error() {
		return $this->error;
	}
	
	/**
	 * Allow dynamic access to the variables in the $data array using the property
	 * syntax
	 * 
	 * @param string $name
	 */
	public function __get($name) {
		if (array_key_exists($name, $this->data)) {
			return $this->data[$name];
		}
		
		throw new Exception('Attempted to access undefined property "'.$name.'"');
	}
}


class UploadInfo {
	
	/**
	 * @var array
	 */
	private $data;
	
	/**
	 * 
	 * @param string	$filepath
	 * @param string	$id
	 * @param string	$sha1
	 * @param bool		$protected	Whether the file has a password protecting it
	 * @param array		$locations
	 * @param int		$delete_at
	 */
	public function __construct(
		UploadRegistry $registry, $id = null, $filepath = '', $sha1 = null, 
			$protected = false, array $locations = null, $delete_at = null) 
	{
		$this->data = [];
		$this->data['registry'] = $registry;
		$this->data['filepath'] = $filepath;
		$this->data['id'] = $id;
		$this->data['sha1'] = $sha1;
		$this->data['protected'] = $protected;
		$this->data['delete_at'] = $delete_at;
		$this->data['locations'] = $locations ?: [];
		$this->data['exists'] = ! empty(trim($filepath));
	}
	
	/**
	 * Allow dynamic access to the variables in the $data array using the property
	 * syntax
	 * 
	 * @param string $name
	 */
	public function __get($name) {
		if (array_key_exists($name, $this->data)) {
			return $this->data[$name];
		}
		
		throw new Exception('Attempted to access undefined property "'.$name.'"');
	}
}