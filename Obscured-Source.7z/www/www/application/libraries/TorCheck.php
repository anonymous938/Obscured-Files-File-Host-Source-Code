<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @class TorCheck
 * 
 * 
 */
class TorCheck
{
    public $ip_list_exit_file = "/var/www/sessions/Tor-ip_list_EXIT.csv";
    public $ip_list_exit_url = "http://torstatus.blutmagie.de/ip_list_exit.php/Tor_ip_list_EXIT.csv";
    public $expiry = 3600;
    public $exit_list = array();

    public function __construct() {
        if (!(file_exists($this->ip_list_exit_file)) || (filemtime($this->ip_list_exit_file) - time()) > $this->expiry) {
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $this->ip_list_exit_url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		$data = curl_exec($ch);
		echo curl_error($ch);
		curl_close ($ch);

		$file = fopen($this->ip_list_exit_file, "w+");
		fputs($file, $data);
		fclose($file);
        }
        $exit_list = file($this->ip_list_exit_file);
        foreach ($exit_list as $ip) {
            array_push($this->exit_list, trim($ip));
        }
    }
    public function check($ip) {
        if(in_array($ip, $this->exit_list)) {
            return true;
        }
        else {
            return false;
        }
    }
}
?>