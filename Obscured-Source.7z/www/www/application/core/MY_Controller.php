<?php

require_once(__DIR__ . '/../config/database.php');

use Crate\PDO\PDO as PDO;

class MY_Controller extends CI_Controller {

	/**
	 * The name of the table in which the details of uploads are stored
	 * 
	 * @var string
	 */
	const UPLOADS_TABLE = 'uploads_efKz69bw8';
	
	public function __construct()
	{
		parent::__construct();
		
		// HOTFIX: 
		// This code is a work around for an issue with the Crate PDO driver
		// where it will hang indefinitely if the Crate server IP address 
		// specified is unreachable. Should be safe to remove once this issue
		// has been resolved: https://github.com/crate/crate-pdo/issues/52
		//
		// We check for the ability to reach the VPN and send the user to some
		// other server with the same parameters otherwise.
		
		$_ = null;
		$sock_p = null;
		$sock_p = fsockopen('10.6.5.1', 4200, $_, $_, 1);
		if (ENVIRONMENT != 'development' && ! $sock_p) {
			$this->config->load('cluster');
			
			// Was it a Tor request?
			$is_tor = preg_match('/\w{16}\.onion$/', $this->input->server('SERVER_NAME'));
			
			// Find a server in list we can re-route to
			$candidates = [];
			foreach($this->config->item('servers') as $name => $server) {
				// Never redirect to the test server
				if ($name == 'test') { continue; }
				
				$candidates[] = $is_tor ? $server['hidden_addr'] : $server['clear_addr'];
			}
			
			// Try to preserve the path to minimize inconvenience
			$server_addr = $candidates[rand(0, count($candidates) - 1)];
			$redirect_url = $server_addr .	$this->input->server('REQUEST_URI');
			
			redirect($redirect_url);
		}
		
		$this->config->load('uploads');
	}
	
	/**
	 * Return the appropraite base URL for the request. If the host is invalid
	 * will throw an error
	 * 
	 * @return string
	 */
	public function get_base_url() {
		$http_host = $this->input->server('HTTP_HOST');

		// Allow anything if in development mode.
		if (ENVIRONMENT == 'development')
		{
			if (!empty($_SERVER['HTTPS'])) {
				return "https://" . $http_host . "";
			}
			else {
				return "http://" . $http_host . "";
			}
		}

		if ($this->input->ip_address() == "127.0.0.1") {
			return ONION_SERVICE;
		}
		elseif (preg_match("/(www\.)?". CLEAR_ID . "\.obscuredfiles\.com$/", $http_host)) 
		{
			return "https://" . $http_host;
		}
		elseif (preg_match("/(www\.)?obscuredfiles\.com$/", $http_host)) 
		{
			return "https://" . $http_host;
		}
		else
		{
			echo REQUEST_INVALID;
			exit;
		}
	}
	
	/**
	 * Generate a delete code for an upload based on some information about it.
	 * The code is derived using an HMAC and then filtered and truncated to give
	 * a 12 character string.
	 * 
	 * @param string $id
	 * @param string $sha1
	 * @param string $created_at
	 * 
	 * @return string
	 */
	protected function generateDeleteCode($id, $sha1, $created_at) 
	{
		// Create an HMAC of the given information using the MD5 digest as well
		// as the secret key for these. 
		// WARNING: Changing this key will render old delete links useless.
		$hmac = hash_hmac(
			'md5', implode('|', [$id, $sha1, $created_at]), DELETE_HMAC_KEY, true);
		
		// Use base64 encoding so we get the a 64 char character space (not hex)
		$base64 = base64_encode($hmac);
		
		// Remove "+" and "/" characters (mess with URLs)
		$base62 = str_replace(['/', '+'], ['', ''], $base64);
		
		// Return the truncated version
		return substr($base62, 0, 12);
	}

	/**
	 * Get a new Crate connection
	 * 
	 * @return array
	 *	First element is the database name and the second a \Crate\PDO\PDO instance
	 */
	protected function connect_crate()
	{
		global $db;
		$db_conf = $db['default'];
		$dsn = $db_conf['dsn'];
		if (empty($dsn)) {
			$ports = is_array($db_conf['port']) ? $db_conf['port'] : [$db_conf['port'],];
			$dsn_parts = [];
			foreach($ports as $port) {
				$dsn_parts[] = $db_conf['hostname'].':'.$port;
			}
			$dsn = 'crate:' . implode(',', $dsn_parts);
		}

		$pdo = new PDO($dsn, null, null, null);
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

		return [$db_conf['database'], $pdo];
	}
	
	/**
	 * Insert a row into Crate
	 * 
	 * @param string $table Name of table to insert into
	 * @param array $row Data to insert
	 * 
	 * @return bool
	 */
	protected function crate_insert($table, $row) 
	{	
		list($db_name, $pdo) = $this->connect_crate();

		$full_table_name = $db_name . '.' . $table;
		$stmt = $pdo->prepare(
				'INSERT INTO ' . $full_table_name
				. ' (' . implode(',', array_keys($row)) . ')'
				. ' VALUES (:' . implode(',:', array_keys($row)) . ')');

		// Create copy of "row" with the keys prefixed by a colon
		$_row = [];
		foreach ($row as $col => $val) {
			$_row[':' . $col] = $val;
		}

		return $stmt->execute($_row);
	}

	/**
	 * Select rows from a table by a WHERE clause
	 * 
	 * @param string	$table
	 * @param array		$where
	 * @param int		$limit
	 * 
	 * @return array Each result in associated array format
	 */
	protected function crate_where($table, $where = null, $limit = null)
	{
		list($db_name, $pdo) = $this->connect_crate();
		
		$sql = 'SELECT * FROM '. $db_name . '.' . $table;
		if (is_array($where)) {
			$sql .= $this->condition_string($where);
		}
		if (!is_null($limit)) {
			$sql .= ' LIMIT ' . intval($limit);
		}
		
		$stmt = $pdo->prepare($sql);
		$stmt->execute($this->param_array($where));

		return array_map(function ($arr) {
				$obj = new stdClass;
				foreach($arr as $k => $v) {
					$obj->{$k} = $v;
				}
				return $obj;
			},
			$stmt->fetchAll(PDO::FETCH_ASSOC)
		);
	}
	
	/**
	 * Select rows from a table by a WHERE clause
	 * 
	 * @param string	$table
	 * @param array		$where
	 * 
	 * @return int
	 */
	protected function crate_delete($table, $where = null) {
		list($db_name, $pdo) = $this->connect_crate();

		$sql = 'DELETE FROM ' . $db_name . '.' . $table;
		if (is_array($where))	{ 
			$sql .= $this->condition_string($where); 
		}
		
		$stmt = $pdo->prepare($sql);
		
		return $stmt->execute($this->param_array($where));
	}
	
	/**
	 * Update the database
	 * 
	 * @param string $table
	 * @param array $where
	 * @param array $values
	 * 
	 * @return int
	 */
	protected function crate_update($table, array $where, array $values) {
		list($db_name, $pdo) = $this->connect_crate();

		$sql = 'UPDATE ' . $db_name . '.' . $table . ' SET ';
		
		$updates = array_map(
			function ($key) use ($values) {
				if (is_int($key)) {
					return $values[$key];
				}
				return $key . '=:u_' . $key;
			}, 
			array_keys($values)
		);
		$sql .= implode(', ', $updates);

		if (is_array($where)) {
			$sql .= $this->condition_string($where);
		}

		$stmt = $pdo->prepare($sql);
		
		return $stmt->execute(
			array_merge(
				$this->param_array($where), $this->param_array($values, 'u_'))
		);
	}

	/**
	 * Create a condition SQL string from a "$where" array
	 * 
	 * @return string
	 */
	protected function condition_string(array $where)
	{
		$sql = ' WHERE ';
		$conditions = array_map(
				function ($key) use ($where) {
			if (is_int($key)) {
				return $where[$key];
			}
			return $key . '=:' . $key;
		}, array_keys($where)
		);
		$sql .= implode(' AND ', $conditions);
		
		return $sql;
	}
	
	/**
	 * Create a parameters array from a "$where" array
	 * 
	 * @param array $where
	 * @param string $prefix
	 */
	protected function param_array(array $where, $prefix = '') 
	{	
		$params = [];
		foreach ($where as $col => $val) {
			if (is_int($col)) {
				continue;
			}
			$params[':' . $prefix . $col] = $val;
		}
		return $params;
	}
}
