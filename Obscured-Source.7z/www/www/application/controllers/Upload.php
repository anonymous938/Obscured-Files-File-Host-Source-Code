<?php

class Upload extends MY_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->helper(array('form', 'url'));
	}

	public function index()
	{
		$this->load->view('upload_form', array('error' => ' '));
	}

	public function do_upload()
	{
		$api = $this->input->post('api') !== null;
		$this->load->library('UploadRegistry', ['loader' => $this->load], 'uploads');
		
		$request = new UploadRequest;
		$request->obscure_name = $this->input->post('obscure') !== null;
		$request->expire_in_24h = $this->input->post('onedayexpire') !== null;
		$request->has_password = $this->input->post('protect') !== null;
		$request->remake_image = $this->input->post('remake') !== null;
		
		$result = $this->uploads->add($request);
		
		$base_url = $this->get_base_url();
		$data['base_url'] = $base_url;
		
		if ( ! $result->good()) {
			$data['error'] = $result->error();
			if ($api) {
				$this->output
        				->set_content_type('application/json')
        				->set_output(json_encode(array('status' => 'error','code' => $data['error']), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES))
					->_display();
				exit;
			}
			$this->load->view('upload_form', $data);
			return;
		}

		if ($result->is_image && $request->remake_image) {
			$image = $this->uploads->image_path($result->file_name);
			if ( ! $this->remake_image($image)) {
				$data['error'] = "WARNING: Error removing the EXIF data from image.";
			}
			$data['remake'] =  true;
		}

		$data['password'] = $request->has_password ? $result->password : false;
		$data['obscured'] = $request->obscure_name;

		$data['requestip'] = $this->input->ip_address();
		$data['localhost'] = false;
		if ($data['requestip'] == "127.0.0.1") {
			$data['localhost'] = true;
			$link_url = ONION_SERVICE;
		} else {
			$this->load->library('TorCheck');
			$data['torip'] = $this->torcheck->check($data['requestip']);
			$link_url = CLEAR_ID_URL;
		}
		
		if ($result->is_image) {
			$data['link'] = $link_url . "/pic/" . $result->file_name;
		} else {
			$data['link'] = DEFAULT_CLEAR_URL . "/?file=" . $result->file_id;
			if ($data['localhost'] || isset($data['torip']) && $data['torip']) {
				$data['link_hidden'] = DEFAULT_ONION_URL . "/?file=" . $result->file_id;
			}
		}

		$data['delete_link'] = $base_url . "/?delete=" . $result->file_id . "&k=" .$result->delete_code;
		$data['file_sha1'] = $result->sha1;
		
		// Fill out keys expected by the view
		foreach(['remake'] as $varname) {
			array_key_exists($varname, $data) || ($data[$varname] = false);
		}

		$data['is_image'] = $result->is_image;
		$data['file_type'] = $result->file_type;
		$data['delete_at'] = $this->input->post('onedayexpire');

		if ($api) {
			$this->output
        			->set_content_type('application/json')
        			->set_output(json_encode(array('status' => 'success', 'data' => $data), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES))
				->_display();
			exit;
		}

		$this->load->view('upload_success', $data);
	}
	
	
	/**
	 * Remove EXIF data from an image
	 * 
	 * @param string $image The absolute filename of the image
	 * 
	 * @return boolean Whether the operation was successful
	 */
	protected function remake_image($image) {
		try {   
			$img = new Imagick($image);
			$img->setImageCompression(imagick::COMPRESSION_JPEG);
			$img->setImageCompressionQuality(70);
			$img->stripImage();
			$img->writeImage($image);
			$img->clear();
		}
		catch(Exception $e) {
			return false;
		}
		return true;
		
	
	}
	/**
 	 * Ensures an ip address is both a valid IP and does not fall within
 	 * a private network range.
 	 */
	protected function get_ip_address()
	{
		$ip_keys = array('HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_X_CLUSTER_CLIENT_IP', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'REMOTE_ADDR');
		foreach ($ip_keys as $key)
		{
			if (array_key_exists($key, $_SERVER) === true)
			{
				foreach (explode(',', $_SERVER[$key]) as $ip)
				{
					// trim for safety measures
					$ip = trim($ip);
					// attempt to validate IP
					if ($this->validate_ip($ip))
					{
						return $ip;
					}
				}
			}
		}
		return isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : false;
	}	

	/**
 	 * Ensures an ip address is both a valid IP and does not fall within
 	 * a private network range.
 	*/
	function validate_ip($ip)
	{
		if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 | FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) === false)
		{
			return false;
		}
		return true;
	}
}
