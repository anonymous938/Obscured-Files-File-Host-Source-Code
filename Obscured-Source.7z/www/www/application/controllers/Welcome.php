<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends MY_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 * 	- or -
	 * 		http://example.com/index.php/welcome/index
	 * 	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	
	public function index()
	{
		if (OFFLINE) {
			echo OFFLINE_MESSAGE;
			die;
		}
		
		session_start();
		if (!isset($_COOKIE["id"])) {
			setcookie("id",rand());
		}

		$data['base_url'] =  $this->get_base_url();
		
		// File request
		if ($this->input->get('file') && strlen($this->input->get('file')) == 8)
		{
			$data['redirect'] = $this->input->get('file');
			$this->file($data);
		}
		elseif ($this->input->get('download') && strlen($this->input->get('download')) == 8)
		{
			$this->handleDownload($data);
		}
		// Delete request
		elseif ($this->input->get('delete') && strlen($this->input->get('delete')) == 8)
		{
			$data['error'] = $this->handleDelete();
			$this->load->view('upload_form', $data);
		}
		elseif ($this->input->get('adminabuse') == "abusepassword")
		{
			$this->abuseadmin($data);			
		}
		else
		{
			$this->load->view('upload_form', $data);
		}
	}

	/**
	 * Handles a /?file request
	 * 
	 * @param array $data Pre-generated view data
	 */
	protected function file(array $data) 
	{
		$this->load->library('UploadRegistry', ['loader' => $this->load], 'uploads');
		$this->load->library('encryption');
		$this->load->library('CrateStore', [], 'crate');
		$this->load->config('cluster');
		
		$file_id = $data['redirect'];
		$upload = $this->uploads->get($file_id);
		
		if ( ! $upload->exists) {
			$data['error'] = FILENOTFOUND_MESSAGE;
			$this->load->view('upload_form', $data);
			return;
		}

		$data['sha1'] = $upload->sha1;
		$data['file'] = "?download=" . $file_id;			
		$data['protected'] =  $upload->protected;
		$data['error'] = $this->input->get('error');

		// Get the URL for the server that will handle the actual download
		$this->load->library(
			'DownloadRoute',
			[
				'servers' => $this->config->item('servers'),
				'upload' => $upload,
				'own_ip' => $this->input->server('SERVER_ADDR') ?
					$this->input->server('SERVER_ADDR') : 
					gethostbyname($this->input->server('SERVER_NAME'))
		]);

		// No one has it?
		if (empty($this->downloadroute->server())) {
			$data['error'] = FILENOTFOUND_MESSAGE;
			$this->load->view('upload_form', $data);
			return;
		}

		//creating encrypted file link for today only
		$data['file_token'] = $this->encryption->encrypt($file_id . $this->encryption->create_key(16));
		$data['link_token'] = $this->encryption->encrypt(time()+300);

		$data['server'] = $this->downloadroute->server()['clear_addr'];
		$data['hidden'] = $this->downloadroute->server()['hidden_addr'];
		
		$data['requestip'] = $this->input->ip_address();
		$data['localhost'] = false;
		if ($data['requestip'] == "127.0.0.1") {
			$data['localhost'] = true;
		} else {
			$this->load->library('TorCheck');
			$data['torip'] = $this->torcheck->check($data['requestip']);
		}

		if (!is_null($upload->delete_at)) {
			$data['delete_at'] = date("H:i:s", $upload->delete_at - time());
		}
		
		$data['referer'] = $this->input->server('HTTP_REFERER');
		
		// Check for the referrer in warning hosts if there is a referer
		if (!empty($data['referer'])) {
		    $referrer_parts = parse_url($data['referer']);
		    $result = $this->crate->select('warning_hosts', [
		        'sha1' => sha1($referrer_parts['host']),
		        'domain' => $referrer_parts['host']
		    ]);
		    if (count($result)) {
		        $this->load->view('referer', $data);
		        return;
		    }
		}

		$this->load->view('file', $data);
		end:
	}
	
	/**
	 * Handle download requests
	 * 
	 * @param array $data
	 */
	protected function handleDownload(array $data)
	{
		if ( ! ($this->input->post('ft') && $this->input->post('lt'))) {
			$data['error'] = "The download keys were not supplied properly.";
			return $this->load->view('upload_form', $data);
		}

		$this->load->library('encryption');
		$file_token = $this->encryption->decrypt($this->input->post('ft'));
		$link_token = $this->encryption->decrypt($this->input->post('lt'));
		
		if (substr($file_token, 0, -16) != $this->input->get('download')) {
			$data['error'] = "The download link supplied is not correct for the "
				. "keys supplied.";
			return $this->load->view('upload_form', $data);
		}

		$sum = $link_token - time();
		if ($sum < 0) {
			$data['expiretime'] = true;
			$data['redirect'] = $this->input->get('download');
			return $this->file($data);
		}
		
		$data['password'] = null;
		if ($this->input->post('password')) {
			$data['password'] = trim($this->input->post('password'));
		}
		$data['file'] = $this->input->get('download');

		// Look up the file from the database
		$result = $this->crate_where(
			self::UPLOADS_TABLE, ['id' => $data['file']], 1);
		if (count($result) === 0) {
			$data['error'] = "failed to get result from database.";
			return $this->load->view('upload_form', $data);
		}
		$row = $result[0];
		
		$data['realpath'] = UPLOAD_BASE_DIR . (is_null($row->delete_at) ? 
				FILE_DIR . '/' . date("m.d.Y", $row->uploaded_at) . '/' : DAY_FILE_DIR) . 
			basename($row->random_name);
		
		if (!file_exists($data['realpath'])){
			$data['error'] = "File Not Propagated Fully";
			return $this->load->view('upload_form', $data);
		}

		// Record this access of the file
		$this->crate_update(
			self::UPLOADS_TABLE, 
			['id' => $data['file']], 
			['accessed_at' => time()]);
		
		$data['test_password'] = $row->password;
		$data['random_name'] = $row->random_name;
		$data['original_name'] = $row->original_name;
		$data['delete_at'] = $row->delete_at;

		$this->load->view('fd', $data);
	}
	 
	/**
	 * Handles a /?delete request
	 * 
	 * @return string
	 */
	protected function handleDelete() 
	{
		// Get the delete key
		$key = $this->input->get('k');
		if (is_null($key)) 
		{
			return "No delete key provided. Please check the URL.";
		}
		
		$results = $this->crate_where(
			self::UPLOADS_TABLE, ['id' => $this->input->get('delete')], 1);
	
		if(count($results) != 1)	// File to delete isn't on record
		{
			return "The specified file is no longer on the system.";
		}
		$result = $results[0];
		
		// Check that the delete key is correct
		$key_check = $this->generateDeleteCode(
			$result->id, $result->sha1, $result->uploaded_at);
		if ($key_check !== $key) 
		{
			return "Invalid delete key provided. Please check the URL.";
		}
		
		// All checks pass, delete the record and the file
		$this->delete($result);
		
		return "File successfully deleted.";
	}
	
	/**
	 * Delete the file with the given row in the database.
	 * 
	 * @param object $row The database row corresponding to the file
	 */
	public function delete($row)
	{
		// Get number of references to the same file in the DB. We use the 
		// delete_at condition to delete either the file in the normal storage
		// or the file in 24 storage independently.
		$references = $this->crate_where(
			self::UPLOADS_TABLE, 
			[
				'sha1' => $row->sha1, 
				'delete_at IS ' . ($row->delete_at ? 'NOT NULL' : 'NULL')
			]
		);
		$no_references = count($references);
		
		// Only delete file on disk if this is the only reference to the file
		if ($no_references <= 1)
		{
			$date_dir = date("m.d.Y", $row->uploaded_at) . '/';
			$fileurl = ($row->delete_at ? DAY_FILE_DIR : FILE_DIR . $date_dir) . $row->random_name;

			// Delete the file on disk
			unlink(UPLOAD_BASE_DIR.$fileurl);
		}
		
		// And the record of it...
		$this->crate_delete(self::UPLOADS_TABLE, ['id' => $row->id]);
	}
	protected function abuseadmin(array $data) 
	{	
		$this->authenticate();
		// Get the delete key
		$this->load->library('encryption');
		ini_set('display_errors', 1);
		ini_set('display_startup_errors', 1);
		error_reporting(E_ALL);
		$data['link_token'] = $this->encryption->encrypt(time()+300);
		$file = $this->input->post('file');
		if (!empty($file)) {
			$data['error']  = $this->abuseremove($file);
		}
		$this->load->view('remove', $data);
	}
	
	protected function abuseremove($link) 
	{
		$this->load->library('UploadRegistry', ['loader' => $this->load], 'uploads');
		$this->load->library('encryption');
		$this->load->config('cluster');
		
		$link_token = $this->encryption->decrypt($this->input->post('lt'));
		if (!$link_token){
			return "Bad Token/Invalid Match2";
		}
		$sum = $link_token - time();
		if ($sum < 0) {
			return "Invalid Key/Time Exhausted.";
		}
		$array = array();
		$lines = explode(PHP_EOL, $link);
		$remove_ref = $this->input->post('clearreference');

		foreach($lines as $string) {

			$string = trim($string);
			if (strlen($string) == 0) {
				continue;
			}
			
			if (strlen($string) != 8) {
				$string = substr($string, strpos($string, "/?file=") + 7);

				if (strlen($string) != 8) {
					$text = "Bad File URL (" . $string . ")";
					$array[] = $text;
					continue;
				}
			}
		
			$upload = $this->uploads->get($string);
			if ( ! $upload->exists) {	// File to delete isn't on record
				$text = "The specified file is no longer on the system. (" . $string . ")";
				$array[] = $text;
				continue;
			}
			
			if ($this->uploads->nuke($string, $this->config->item('servers'), $remove_ref)) {
				// All checks pass, delete the record and the file
				$this->uploads->report_abusive_file($upload->sha1);
				$text = "File successfully deleted.";
			} 
			else {
				$text = "File not found on this system.";	
			}

			$remove_ref && ($text .= " Reference Removed.");
			
			$text = $text . " (" . $string . ")";
			$array[] = $text;
		}
		
		return $array;
	}
	
	protected function authenticate()
	{
		if (!isset($_SERVER['PHP_AUTH_USER'])) {
			header("WWW-Authenticate: Basic realm=\"Private Area\"");
			header("HTTP/1.0 401 Unauthorized");
			print "No credentials entered.";
			exit;
		}
		elseif (($_SERVER['PHP_AUTH_USER'] == ABUSE_USER) && ($_SERVER['PHP_AUTH_PW'] == ABUSE_PASS)) {
           			return;
		}
		else {
			header("WWW-Authenticate: Basic realm=\"Private Area\"");
			header("HTTP/1.0 401 Unauthorized");
            		print "Invalid credentials.";
            		exit;
        	}
    	}
}
