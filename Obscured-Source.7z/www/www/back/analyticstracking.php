<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="theme-color" content="#292929">
<meta name="msapplication-navbutton-color" content="#292929">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="#292929">
<script type="text/javascript" src="/public/analytics.js"></script>
<noscript><link href="https://www.google-analytics.com/collect?v=1&tid=UA-[YOURIDHERE]-1&cid=<?php echo $_COOKIE["id"]; ?>&uid=<?php echo session_id(); ?>&ni=1&t=pageview&dp=<?php echo $_SERVER["REQUEST_URI"]; ?>&aip=1&z=<?php echo rand(); ?>" rel="preload"></noscript>