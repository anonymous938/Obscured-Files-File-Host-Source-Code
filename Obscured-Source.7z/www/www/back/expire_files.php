<?php

/** 
 * Command line script to remove files from the system which have passed their
 * delete by time. 
 */

define('BASEPATH', __DIR__);

require_once __DIR__ . '/../application/vendor/autoload.php';
require_once __DIR__ . '/../application/config/database.php';
require_once __DIR__ . '/../application/config/uploads.php';

use Crate\PDO\PDO as PDO;


// Connect to the database
global $db;
$db_conf = $db['default'];
$dsn = empty($db_conf['dsn']) ?
		'crate:' . $db_conf['hostname'] . ':' . $db_conf['port'] : $db_conf['dsn'];
$pdo = new PDO($dsn, null, null, null);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$uploads_table = $db_conf['database'] . '.' . 'uploads_efKz69bw8';

// Find all files with an expiry
$sql = 'SELECT id, random_name, sha1, delete_at'
		. ' FROM ' . $uploads_table
		. ' WHERE delete_at IS NOT NULL';
$results = $pdo->query($sql);
$files = $results->fetchAll(PDO::FETCH_ASSOC);

// Find all the sha1s that still have unexpired links to them
$immune_sha1 = [];
foreach($files as $file) {
	if ($file['delete_at'] > time() && !in_array($file['sha1'], $immune_sha1)) {
		$immune_sha1[] = $file['sha1'];
	}
}

// Delete the file on disk as well as the record
$del_stmt = $pdo->prepare('DELETE FROM ' . $uploads_table . ' WHERE id = :id');
foreach($files as $file) {

	if ($file['delete_at'] > time()) { continue; } 
	
	// Delete the file on disk
	if ( ! in_array($file['sha1'], $immune_sha1)) {
		$fname = UPLOAD_BASE_DIR . DAY_FILE_DIR . $file['random_name'];
		file_exists($fname) && unlink($fname);
	}

	$del_stmt->execute(['id' => $file['id']]);
}

