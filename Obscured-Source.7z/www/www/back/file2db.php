<?php
/**
 * This script is intended for importing uploads recorded in the file based
 * system into the database based system the site is being transitioned to.
 * 
 * In order to run it, simply execute this PHP file from the command line.
 */

if (php_sapi_name() !== 'cli')
{
	die('This script is intended to be run by the CLI only.');
}

define('UPLOADS_TABLE', 'uploads_efKz69bw8');

// Load the CodeIgniter database configuration
define('BASEPATH', dirname(__DIR__));
require_once BASEPATH.'/application/config/database.php';
require_once BASEPATH.'/application/config/uploads.php';

/**
 * Function needed to intelligently joint paths
 *
 * @see http://stackoverflow.com/a/15575293/1852838
 */
function join_paths() {
    $paths = array();

    foreach (func_get_args() as $arg) {
        if ($arg !== '') { $paths[] = $arg; }
    }

    return preg_replace('#/+#','/',join('/', $paths));
}

// Connect to the database
$db_conf = $db[$active_group];
$pdo = new PDO(
	'mysql:host='.$db_conf['hostname'].';dbname='.$db_conf['database'],
	$db_conf['username'],
	$db_conf['password']);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Go through each line in the "filelink.txt" file
$f = fopen(BASEPATH.'/back/filelink.txt', 'r');
if ( ! $f)
{
	die("An error occurred while trying to open the file for reading.\n");
}

// Prepare the database statement we'll use to check for files that are already
// recorded in the database.
$id_stmt = $pdo->prepare("SELECT id FROM ".UPLOADS_TABLE." WHERE id = :file_id");

// Prepare the database statement we'll use for inserts. Since the previous store
// didn't support all the features of the current system, we only insert into
// a few columns.
$insert_stmt = $pdo->prepare("INSERT INTO ".UPLOADS_TABLE
	. " (`id`, `random_name`, `original_name`, `sha1`, `uploaded_at`) "
	. " VALUES (:id, :raw_name, :download_name, :sha1, :uploaded_at)");

// Go through each line in the file store
while (($line = fgets($f)) !== false) 
{
	if (preg_match('/.{8},[^,]+,.+/', $line))
	{
		list($id, $path, $name) =  explode(',', $line);
	}
	elseif (preg_match('/.{8},.+/', $line)) 
	{
		list($id, $path) =  explode(',', $line);
		$name = basename($path);
	}
	else { echo "?"; continue; }
	
	$full_path = trim(join_paths(UPLOAD_BASE_DIR, $path));
	if ( ! file_exists($full_path))
	{
		echo "x"; continue;
	}
	
	// Check the database for the record
	$id_stmt->execute([':file_id' => $id]);
	if ($id_stmt->fetchObject() !== false)
	{
		// File with this ID is in the DB. Perhaps we could choose to check the 
		// SHA1 but if two different SHA1s have the same id, something bad 
		// happened that is bigger than this script.
		echo "-"; continue;
	}
	
	// Images weren't recorded in the DB
	
	$finfo = pathinfo($path);
	if (array_key_exists('extension', $finfo) && 
		(in_array(strtolower($finfo['extension']), ['jpg', 'jpeg', 'gif', 'png', 'webm'])))
	{
		echo "o"; continue;
	}
	
	// Strip out information from the path
	$insert_stmt->execute([
		':id'				=> $id,
		':raw_name'			=> trim(ltrim($path, '/ul/')),
		':download_name'	=> trim($name),
		':sha1'				=> sha1_file($full_path),
		':uploaded_at'		=> filemtime($full_path),
	]);
	
	if ($insert_stmt->rowCount() === 1) { echo "+"; }
	else								{ echo "*"; }
}
echo "\n";

fclose($f);

