<?php

/**
 * Minimal API for small inter-node communication without the overhead of starting
 * up the whole CodeIgniter framework.
 * 
 * Should this grow beyond one or two methods, it should be made into a route
 * and given its own controller.
 */


/**
 * The "have_file" method checks whether a particular file is present on this
 * server's file system. The parameters that must be provided are:
 *
 * @param file_path - The full path to the file on disk
 * @param sha1		- The SHA1 hash of the file
 * 
 * The server will respond with either "0" or "1".
 */
if (filter_has_var(INPUT_GET, 'have_file')) {
	header("Connection: Close");
	$message = FileProbeMessage::decode($_GET['have_file']);
	if ( ! $message) {
		echo "Improper request.";
		http_response_code(400);
		return;
	}
	
	$path = $message->getPath();
	$sha1 = $message->getSHA1();
	if (file_exists($path) && (sha1_file($path)) == $sha1) { 
		die("1");
	}
	die("0");
}
/**
 * The "delete_file" method will delete the specified file if it is found on this
 * server's file system. The parameters that must be provided are:
 *
 * @param file_path - The full path to the file on disk
 * @param sha1		- The SHA1 hash of the file
 * 
 * The server will respond with either "0" or "1" depending on whether the 
 * specified file was deleted or not.
 */
elseif (filter_has_var(INPUT_GET, 'delete_file')) {
	header("Connection: Close");
	$message = FileProbeMessage::decode($_GET['delete_file']);
	if ( ! $message) {
		echo "Improper request.";
		http_response_code(400);
		return;
	}
	
	$path = $message->getPath();
	$sha1 = $message->getSHA1();
	if (file_exists($path) && (sha1_file($path) == $sha1) && unlink($path)) {
		die("1");
	}
	die("0");
}


/**
 * @class FileProbeMessage
 * 
 * FileProbeMessage is responsible for encoding a path, SHA1 pair into a string
 * that can be sent over the wire and decoded again.
 */
class FileProbeMessage
{
	/**
	 * Length of a hex encoded SHA1 digest
	 * 
	 * @var int
	 */
	const SHA1_LENGTH = 40;
	
	private $path = '';
	private $sha1 = '';
	
	/**
	 * @param string $path	The path of the file to check for
	 * @param string $sha1	The hex encoded SHA1 digest of the file
	 */
	public function __construct($path, $sha1) {
		$this->path = $path;
		$this->sha1 = $sha1;
	}
	
	public function getPath() {
		return $this->path;
	}
	
	public function getSHA1() {
		return $this->sha1;
	}
	
	/**
	 * @param string $message The message as previously encoded by this class
	 * 
	 * @return FileProbeMessage|false
	 */
	public static function decode($message) {
		$clear_text = APIMessage::decode($message);
		if ( ! $clear_text) { return false; }
		
		$parts = explode('|', $clear_text, 2);
		if (count($parts) < 2) { return false; }
		
		// First part should be SHA1_LENGTH long
		if (strlen($parts[0]) != self::SHA1_LENGTH) { return false; }
		
		// Second part shouldn't be empty
		if (strlen($parts[1]) == 0) { return false; }
		
		list($sha1, $path) = $parts;
		return new FileProbeMessage($path, $sha1);
	}
	
	/**
	 * Return a string that can be sent over the wire safely
	 * 
	 * @return string
	 */
	public function encode() {
		return APIMessage::encode($this->sha1.'|'.$this->path);
	}
}


/**
 * @class APIMessage
 * 
 * APIMessage is the lowest layer of the communication and is responsible for 
 * any encryption and compression of messages that will go between the servers.
 */
class APIMessage
{
	// TODO: Add in a message expiry to discourage replay attacks

	// TODO: Consider compressing payload message.

	// TODO: The static functions below are just placeholders for a private
	// constant. Once the feature is merged into PHP, these should be replaced:
	// https://wiki.php.net/rfc/class_const_visibility
	
	/**
	 * Cipher used for encryption
	 * 
	 * @return string
	 */
	private static function CIPHER() {
		return 'aes-128-cbc';
	}
	
	/**
	 * Key we use to encrypt and decrypt communications. 
	 * @return string
	 */
	private static function KEY() {
		return 'BF3LQRMDeCW4rpsQ';
	}
	
	 /**
	 * Length of a base64 encoded 16 byte IV
	 * 
	 * @return int
	 */
	private static function IV_LENGTH() {
		return 24;
	}
	
	/**
	 * Substitutions made to make base 64 encoding URL safe
	 * 
	 * @var array
	 */
	const B64_TRANSLATION = ['+' => '.', '/' => '_', '=' => '-'];
	
	/**
	 * @param string	$text Raw text
	 * 
	 * @return string
	 */
	public static function encode($text) {
		$iv = openssl_random_pseudo_bytes(16);
		$enc_text = openssl_encrypt($text, self::CIPHER(), self::KEY(), 0, $iv);
		$raw_b64 = $enc_text.'!'.base64_encode($iv);
		return self::escape_base64($raw_b64);
	}
	
	/**
	 * If any step of the decryption attempt fails, false will be returned instead
	 * of the cleartext.
	 * 
	 * @param string	$text Encoded message
	 * 
	 * @return string|false
	 */
	public static function decode($text) {

		// Expect 1 base 64 encoded string, a colon and then another b64 string
		// The line below should thus produce exactly two non-empty strings
		$parts = explode('!', $text);
		
		if (count($parts) != 2)	{ return false; }
		
		// Non-empty first part
		if (strlen($parts[0]) == 0)	{ return false; }
		
		// We know the 2nd part is IV_LENGTH characters long
		if (strlen($parts[1]) != self::IV_LENGTH())	{ return false; }
		
		list($raw_data, $raw_iv) = $parts;
		$data = self::unescaped_base64($raw_data);
		$iv = self::unescaped_base64($raw_iv);
		return openssl_decrypt(
			$data, self::CIPHER(), self::KEY(), 0, base64_decode($iv));
	}
	
	/**
	 * Substitute some characters which are not safe for use in URLs
	 * 
	 * @param string $raw
	 * @return string
	 */
	private static function escape_base64($raw) {
		return str_replace(
			array_keys(self::B64_TRANSLATION), 
			array_values(self::B64_TRANSLATION), 
			$raw);
	}
	
	/**
	 * Undo the result of running the escape_base64 function
	 * 
	 * @param srting $escaped
	 * @return string
	 */
	private static function unescaped_base64($escaped) {
		return str_replace(
			array_values(self::B64_TRANSLATION), 
			array_keys(self::B64_TRANSLATION), 
			$escaped);
	}
}